
"use client";

import * as React from 'react';
import Link from 'next/link';
import { Download, Menu, Home, DownloadCloud } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger, SheetClose } from '@/components/ui/sheet';
import type { Profile } from '@/lib/types';
import { useTheme } from 'next-themes';
import { ThemeToggle } from './theme-toggle';

const mainNavItems = [
  { href: '#home', label: 'Home' },
  { href: '#about', label: 'About' },
  { href: '#portfolio', label: 'Portfolio' },
  { href: '/blog', label: 'Blog' },
  { href: '#skills', label: 'Skills' },
  { href: '#contact', label: 'Contact' },
];

const subPageNavItems = [
  { href: '/', label: 'Back to Home', icon: Home },
];

type HeaderProps = {
    isSubPage?: boolean;
    profile: Profile;
}

export function Header({ isSubPage = false, profile }: HeaderProps) {
  const { setTheme } = useTheme();
  const navItems = isSubPage ? subPageNavItems : mainNavItems;
  const brandLink = isSubPage ? "/" : "#home";

  React.useEffect(() => {
    if (profile.siteTheme) {
      setTheme(profile.siteTheme);
    }
  }, [profile.siteTheme, setTheme]);

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 max-w-screen-2xl items-center">
        <div className="mr-4 flex">
          <Link href={brandLink} className="mr-6 flex items-center space-x-2">
            <span className="font-bold font-headline">{profile.name}</span>
          </Link>
        </div>

        <div className="flex flex-1 items-center justify-end space-x-2">
          <nav className="hidden md:flex items-center space-x-6 text-sm font-medium">
            {navItems.map((item) => (
              <Link
                key={item.label}
                href={item.href}
                className="transition-colors hover:text-primary flex items-center gap-1"
              >
                {item.icon && <item.icon className="h-4 w-4" />}
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="hidden md:flex items-center space-x-4">
            <Button asChild className="animate-pulse-glow">
              <a href={profile.cvUrl} target="_blank" rel="noopener noreferrer" download>
                <Download className="h-4 w-4" />
                Download CV
              </a>
            </Button>
            <ThemeToggle />
          </div>

          <div className="md:hidden">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Menu className="h-5 w-5" />
                  <span className="sr-only">Toggle Menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[300px] sm:w-[400px]">
                <div className="flex justify-between items-center mt-4">
                  <h2 className="text-lg font-semibold font-headline">Navigation</h2>
                </div>
                <nav className="flex flex-col gap-4 mt-4">
                  {navItems.map((item) => (
                    <SheetClose key={item.label} asChild>
                      <Link
                        href={item.href}
                        className="block px-2 py-1 text-lg"
                      >
                        {item.label}
                      </Link>
                    </SheetClose>
                  ))}
                   <Button asChild className="mt-4 animate-pulse-glow">
                      <a href={profile.cvUrl} target="_blank" rel="noopener noreferrer" download>
                        <Download className="h-4 w-4" />
                        Download CV
                      </a>
                    </Button>
                    <div className="flex justify-center pt-4">
                        <ThemeToggle />
                    </div>
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
