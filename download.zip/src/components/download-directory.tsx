
'use client';

import { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { DownloadCard } from '@/components/download-card';
import type { Downloadable } from '@/lib/types';
import { Search } from 'lucide-react';

type DownloadDirectoryProps = {
  initialItems: Downloadable[];
  filters: string[];
};

export function DownloadDirectory({ initialItems, filters }: DownloadDirectoryProps) {
  const [activeFilter, setActiveFilter] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredItems = useMemo(() => {
    let items = initialItems;

    if (activeFilter !== 'All') {
      items = items.filter((item) => item.category === activeFilter);
    }
    
    if (searchTerm) {
      items = items.filter(item =>
        item.title.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    return items;
  }, [activeFilter, searchTerm, initialItems]);

  return (
    <>
      <div className="flex flex-col sm:flex-row gap-4 justify-center my-8">
        <div className="relative flex-grow max-w-sm mx-auto sm:mx-0">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search items..."
            className="pl-10 h-11"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>
      <div className="flex justify-center my-8 space-x-2 flex-wrap gap-y-2">
        {filters.map((filter) => (
          <Button
            key={filter}
            variant={activeFilter === filter ? 'default' : 'secondary'}
            onClick={() => setActiveFilter(filter)}
            className="capitalize"
          >
            {filter}
          </Button>
        ))}
      </div>
      <div className="grid gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 justify-center">
        {filteredItems.length > 0 ? (
            filteredItems.map((item) => <DownloadCard key={item.id} item={item} />)
        ) : (
          <p className="col-span-full text-center text-muted-foreground mt-8">
            No items found. Try adjusting your search or filter.
          </p>
        )}
      </div>
    </>
  );
}
