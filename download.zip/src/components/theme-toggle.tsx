
"use client"

import * as React from "react"
import { useTheme } from "next-themes"

export function ThemeToggle() {
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = React.useState(false)

  React.useEffect(() => {
    setMounted(true)
  }, [])
  
  if (!mounted) {
    // Avoid showing the toggle on the server to prevent hydration mismatch
    return <div className="h-7 w-12 rounded-full bg-muted animate-pulse" />
  }

  const cycleTheme = () => {
    if (theme === 'system' || theme === 'light') {
      setTheme('dark');
    } else {
      setTheme('light');
    }
  }
  
  const currentTheme = theme === 'system' ? 'light' : theme;

  return (
    <div className="theme-toggle-switch">
      <label className="theme-switch-label">
        <input type="checkbox" className="theme-checkbox" onChange={cycleTheme} checked={currentTheme === 'dark'}/>
        <span className="theme-slider" />
      </label>
    </div>
  )
}
