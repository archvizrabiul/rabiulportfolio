import Image from 'next/image';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { ArrowDown, Download } from 'lucide-react';
import type { Profile } from '@/lib/types';

type HeroSectionProps = {
  profile: Profile;
}

export function HeroSection({ profile }: HeroSectionProps) {
  return (
    <section id="home" className="w-full py-12 md:py-24 lg:py-32 bg-background">
      <div className="container px-4 md:px-6">
        <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 xl:gap-16 items-center">
           <div className="flex flex-col items-center order-1 lg:order-2">
             <Image
                src={profile.profilePictureUrl}
                data-ai-hint="profile picture"
                alt={profile.name}
                width={400}
                height={400}
                className="mx-auto aspect-square overflow-hidden rounded-full object-cover max-w-[240px] w-full sm:max-w-[300px] border-4 border-primary/20"
                priority
              />
           </div>

          <div className="flex flex-col justify-center space-y-4 text-center lg:text-left order-2 lg:order-1">
            <div className="space-y-2">
              <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl font-headline">
                {profile.name}
              </h1>
              <p className="max-w-[600px] text-lg text-muted-foreground sm:text-xl md:text-2xl">
                {profile.title}
              </p>
              <p className="max-w-[600px] text-base text-foreground/80 sm:text-lg pt-2">
                Welcome to my creative space where architecture meets artistry and innovation.
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row justify-center lg:justify-start pt-4">
              <Button asChild size="lg" className="hidden sm:inline-flex">
                  <Link href="#contact">Contact Me</Link>
              </Button>

              <Button asChild size="lg" className="sm:hidden">
                  <a href={profile.cvUrl} download>
                      <Download className="h-4 w-4" />
                      Download CV
                  </a>
              </Button>

              <Button asChild variant="secondary" size="lg">
                  <Link href="#portfolio">
                  View My Work
                  <ArrowDown className="ml-2 h-4 w-4" />
                  </Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
