import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Cpu, User } from 'lucide-react';

const softwareSkills = ['Revit', 'AutoCAD', '3ds Max', 'Photoshop', 'MS Project', 'MS Office', 'Corona', 'V-ray', 'Enscape'];
const personalSkills = ['Leadership', 'Time Management', 'Management Skills', 'Teamwork', 'Problem Solving'];

export function SkillsSection() {
  return (
    <section id="skills" className="w-full py-12 md:py-24 lg:py-32">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl font-headline">My Skills</h2>
            <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              A blend of technical expertise and soft skills to bring visions to life.
            </p>
          </div>
        </div>
        <div className="grid gap-8 md:grid-cols-2">
            <Card className="bg-secondary border-border/50">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 font-headline text-xl"><Cpu className="w-6 h-6 text-primary"/> Software Proficiency</CardTitle>
                </CardHeader>
                <CardContent className="flex flex-wrap gap-2">
                    {softwareSkills.map(skill => (
                        <Badge key={skill} variant="outline" className="text-sm sm:text-base font-medium px-4 py-2 rounded-lg border-primary/30 bg-primary/5 hover:bg-primary/10 transition-colors duration-300">
                          {skill}
                        </Badge>
                    ))}
                </CardContent>
            </Card>
            <Card className="bg-secondary border-border/50">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 font-headline text-xl"><User className="w-6 h-6 text-primary"/> Personal Skills</CardTitle>
                </CardHeader>
                <CardContent className="flex flex-wrap gap-2">
                    {personalSkills.map(skill => (
                         <Badge key={skill} variant="outline" className="text-sm sm:text-base font-medium px-4 py-2 rounded-lg border-primary/30 bg-primary/5 hover:bg-primary/10 transition-colors duration-300">
                          {skill}
                        </Badge>
                    ))}
                </CardContent>
            </Card>
        </div>
      </div>
    </section>
  );
}
