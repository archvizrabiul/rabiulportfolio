
"use client";

import { useState, useMemo } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { Card, CardContent, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ProjectDetailsDialog } from '@/components/project-details-dialog';
import type { Project } from '@/lib/types';
import { ArrowRight } from 'lucide-react';

type PortfolioSectionProps = {
  initialProjects: Project[];
  filters: string[];
  totalProjectsCount?: number;
  isHomePage?: boolean;
}

export function PortfolioSection({ initialProjects, filters, totalProjectsCount, isHomePage = false }: PortfolioSectionProps) {
  const [activeFilter, setActiveFilter] = useState('All');
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  const filteredProjects = useMemo(() => {
    if (activeFilter === 'All') {
      return initialProjects;
    }
    return initialProjects.filter((p) => p.category === activeFilter);
  }, [activeFilter, initialProjects]);
      
  const projectsToDisplay = filteredProjects;

  const handleOpenDialog = (project: Project) => {
    setSelectedProject(project);
  };

  const handleCloseDialog = () => {
    setSelectedProject(null);
  }

  const showViewAllButton = isHomePage && totalProjectsCount && totalProjectsCount > 6;

  return (
    <section id="portfolio" className="w-full py-12 md:py-24 lg:py-32">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl font-headline">My Portfolio</h2>
            <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              A selection of my work in architectural visualization, 3D modeling, and AI-driven design. Click a project to see more.
            </p>
          </div>
        </div>

        <div className="flex justify-center my-8 space-x-2 flex-wrap gap-y-2">
          {filters.map(filter => (
            <Button
              key={filter}
              variant={activeFilter === filter ? 'default' : 'secondary'}
              onClick={() => setActiveFilter(filter)}
            >
              {filter}
            </Button>
          ))}
        </div>

        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {projectsToDisplay.length > 0 ? projectsToDisplay.map(project => (
            <Card 
              key={project.id} 
              className="group overflow-hidden flex flex-col bg-secondary border-2 border-transparent hover:border-primary transition-all duration-300 ease-in-out hover:shadow-lg hover:-translate-y-1 cursor-pointer"
              onClick={() => handleOpenDialog(project)}
            >
              <div className="overflow-hidden">
                <Image
                  src={project.image || "https://placehold.co/600x400.png"}
                  alt={project.title}
                  data-ai-hint={project.hint}
                  width={600}
                  height={400}
                  className="aspect-video object-cover w-full transition-transform duration-500 ease-in-out group-hover:scale-110"
                />
              </div>
              <CardContent className="p-6 flex-grow">
                <CardTitle className="font-headline text-xl">{project.title}</CardTitle>
                <p className="text-sm text-muted-foreground">{project.category}</p>
                 <p className="text-sm text-foreground/80 mt-2 line-clamp-2">
                    {project.description}
                </p>
              </CardContent>
            </Card>
          )) : <p className="col-span-full text-center text-muted-foreground">No projects found for this category.</p>}
        </div>
        
        {showViewAllButton && (
          <div className="text-center mt-12">
            <Button asChild size="lg">
              <Link href="/portfolio">
                View All Projects <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        )}

      </div>
      <ProjectDetailsDialog 
        isOpen={!!selectedProject} 
        onOpenChange={(isOpen) => !isOpen && handleCloseDialog()} 
        project={selectedProject} 
      />
    </section>
  );
}
