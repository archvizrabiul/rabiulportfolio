import { Mail, Phone, MapPin } from 'lucide-react';
import { ContactForm } from '@/components/contact-form';

export function ContactSection() {
  return (
    <section id="contact" className="w-full py-12 md:py-24 lg:py-32 bg-secondary">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl font-headline">Get In Touch</h2>
            <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              Have a project in mind or just want to say hello? I'd love to hear from you.
            </p>
          </div>
        </div>
        <div className="grid gap-10 lg:grid-cols-2">
          <div className="space-y-6">
            <h3 className="text-xl font-bold font-headline">Contact Details</h3>
            <div className="space-y-4">
              <div className="flex items-start gap-4">
                <Mail className="mt-1 h-6 w-6 text-primary" />
                <div>
                  <h4 className="font-semibold">Email</h4>
                  <a href="mailto:rabiulrami@gmail.com" className="text-muted-foreground hover:text-primary transition-colors">
                    rabiulrami@gmail.com
                  </a>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <Phone className="mt-1 h-6 w-6 text-primary" />
                <div>
                  <h4 className="font-semibold">Phone</h4>
                  <p className="text-muted-foreground">+88015 189 25074</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <MapPin className="mt-1 h-6 w-6 text-primary" />
                <div>
                  <h4 className="font-semibold">Location</h4>
                  <p className="text-muted-foreground">378/1, West Shewrapara, Dhaka</p>
                </div>
              </div>
            </div>
          </div>
          <div>
             <ContactForm />
          </div>
        </div>
      </div>
    </section>
  );
}
