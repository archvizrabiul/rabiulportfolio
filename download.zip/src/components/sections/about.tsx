import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Building, Award, Briefcase } from 'lucide-react';
import type { Profile } from '@/lib/types';

type AboutSectionProps = {
  profile: Profile;
}

export function AboutSection({ profile }: AboutSectionProps) {
    return (
        <section id="about" className="w-full py-12 md:py-24 lg:py-32">
            <div className="container px-4 md:px-6">
                <div className="flex flex-col items-center justify-center space-y-4 text-center">
                    <div className="space-y-2">
                        <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl lg:text-5xl font-headline">About Me</h2>
                        <p className="max-w-[900px] text-muted-foreground md:text-xl whitespace-pre-line">
                           {profile.bio}
                        </p>
                    </div>
                </div>
                <div className="mx-auto grid max-w-5xl items-start gap-8 sm:grid-cols-1 md:gap-12 lg:grid-cols-3 mt-12">
                    <Card className="bg-secondary border-border/50 transition-all duration-300 hover:shadow-primary/20 hover:shadow-lg hover:-translate-y-1">
                        <CardHeader className="flex flex-row items-center gap-4">
                            <Building className="w-8 h-8 text-primary" />
                            <CardTitle className="font-headline text-xl">Education</CardTitle>
                        </CardHeader>
                        <CardContent>
                            {profile.education.map((edu, index) => (
                                <div key={index} className="mb-4 last:mb-0">
                                    <h3 className="font-semibold">{edu.institution}</h3>
                                    <p className="text-sm text-muted-foreground">{edu.period}</p>
                                    <p className="text-sm">{edu.degree}</p>
                                    <p className="text-xs text-muted-foreground mt-1">Focus: {edu.focus}</p>
                                </div>
                            ))}
                        </CardContent>
                    </Card>
                    <Card className="bg-secondary border-border/50 transition-all duration-300 hover:shadow-primary/20 hover:shadow-lg hover:-translate-y-1">
                        <CardHeader className="flex flex-row items-center gap-4">
                            <Award className="w-8 h-8 text-primary" />
                            <CardTitle className="font-headline text-xl">Certification</CardTitle>
                        </CardHeader>
                        <CardContent>
                             {profile.certifications.map((cert, index) => (
                                <div key={index} className="mb-4 last:mb-0">
                                    <h3 className="font-semibold">{cert.program}</h3>
                                    <p className="text-sm text-muted-foreground">{cert.period}</p>
                                    <p className="text-sm">{cert.field}</p>
                                    <p className="text-xs text-muted-foreground mt-1">Skills: {cert.skills}</p>
                                </div>
                            ))}
                        </CardContent>
                    </Card>
                    <Card className="bg-secondary border-border/50 transition-all duration-300 hover:shadow-primary/20 hover:shadow-lg hover:-translate-y-1">
                        <CardHeader className="flex flex-row items-center gap-4">
                            <Briefcase className="w-8 h-8 text-primary" />
                            <CardTitle className="font-headline text-xl">Experience</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <Accordion type="single" collapsible className="w-full">
                                {profile.experience.map((job, index) => (
                                    <AccordionItem value={`item-${index}`} key={index}>
                                        <AccordionTrigger className="text-left">{job.role}</AccordionTrigger>
                                        <AccordionContent>
                                            <p className="text-sm font-semibold">{job.company}</p>
                                            <p className="text-xs text-muted-foreground">{job.period}</p>
                                            <p className="mt-2 text-sm text-foreground/80">{job.description}</p>
                                        </AccordionContent>
                                    </AccordionItem>
                                ))}
                            </Accordion>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </section>
    );
}
