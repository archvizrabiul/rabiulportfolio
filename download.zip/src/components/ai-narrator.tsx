"use client"

import { useFormState } from "react-dom"
import { useEffect, useState, useTransition } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"

import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { enhanceDescriptionAction } from "@/app/actions"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
    Form,
    FormControl,
    FormField,
    FormItem,
    FormLabel,
    FormMessage,
} from "@/components/ui/form"
import { Label } from "@/components/ui/label"
import { Wand2, Copy, Check } from "lucide-react"

const narratorSchema = z.object({
  description: z.string().min(10, "Please provide a more detailed description (min 10 characters)."),
})

type NarratorFormValues = z.infer<typeof narratorSchema>

type AINarratorProps = {
  initialDescription: string
  children: React.ReactNode
}

export function AINarrator({ initialDescription, children }: AINarratorProps) {
  const [open, setOpen] = useState(false);
  const [enhancedText, setEnhancedText] = useState("");
  const [copied, setCopied] = useState(false);
  const [state, formAction] = useFormState(enhanceDescriptionAction, { message: null, enhancedDescription: null });
  const [isPending, startTransition] = useTransition();
  const { toast } = useToast()

  const form = useForm<NarratorFormValues>({
    resolver: zodResolver(narratorSchema),
    defaultValues: {
      description: initialDescription,
    },
  })

  useEffect(() => {
    if (state.message === 'Success' && state.enhancedDescription) {
        setEnhancedText(state.enhancedDescription);
    } else if (state.message && state.message !== 'Success') {
        toast({
            title: "Error",
            description: state.message,
            variant: "destructive"
        })
    }
  }, [state, toast])
  
  const handleCopyToClipboard = () => {
    navigator.clipboard.writeText(enhancedText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  
  const onSubmit = (data: NarratorFormValues) => {
    startTransition(() => {
        const formData = new FormData();
        formData.append('description', data.description);
        formAction(formData);
    });
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="sm:max-w-[625px]">
        <DialogHeader>
          <DialogTitle className="font-headline flex items-center gap-2"><Wand2 /> AI Project Narrator</DialogTitle>
          <DialogDescription>
            Enhance your project description with AI. Provide the basic details, and let our AI craft a compelling narrative.
          </DialogDescription>
        </DialogHeader>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Form {...form}>
            <form
              onSubmit={form.handleSubmit(onSubmit)}
              className="space-y-4"
            >
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Original Description</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Describe your project..." className="h-48" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit" disabled={isPending} className="w-full">
                {isPending ? "Enhancing..." : "Enhance Description"}
              </Button>
            </form>
          </Form>
          <div className="space-y-4">
              <Label>Enhanced Description</Label>
              <div className="relative">
                <Textarea 
                    readOnly 
                    value={enhancedText} 
                    placeholder="AI-enhanced description will appear here..."
                    className="h-48 bg-muted"
                />
                 {enhancedText && (
                    <Button variant="ghost" size="icon" className="absolute top-2 right-2 h-7 w-7" onClick={handleCopyToClipboard}>
                        {copied ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
                    </Button>
                )}
              </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
