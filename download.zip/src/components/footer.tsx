export function Footer() {
  return (
    <footer className="py-6 w-full shrink-0 items-center px-4 md:px-6 border-t">
      <div className="container mx-auto text-center">
        <p className="text-xs text-muted-foreground">
          &copy; {new Date().getFullYear()} Rabiul Hasan. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
