
"use client";

import Image from 'next/image';
import * as React from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogClose,
} from '@/components/ui/dialog';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
  type CarouselApi,
} from '@/components/ui/carousel';
import { ScrollArea } from '@/components/ui/scroll-area';
import type { Project } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Download, ShieldCheck, Cpu, Paintbrush, Wand2, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';


type ProjectDetailsDialogProps = {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  project: Project | null;
};

export function ProjectDetailsDialog({ isOpen, onOpenChange, project }: ProjectDetailsDialogProps) {
  const [api, setApi] = React.useState<CarouselApi>()
  const [current, setCurrent] = React.useState(0)
  
  React.useEffect(() => {
    if (!api) {
      return
    }
 
    setCurrent(api.selectedScrollSnap())
 
    api.on("select", () => {
      setCurrent(api.selectedScrollSnap())
    })
  }, [api])

  if (!project) return null;

  const allMedia: {type: 'video' | 'image', src: string, thumb: string}[] = [];
    
  if (project.video) {
      allMedia.push({type: 'video', src: project.video, thumb: project.image});
  }

  const allImages = [project.image, ...(project.gallery || [])];
  allImages.forEach(imgSrc => {
      allMedia.push({type: 'image', src: imgSrc, thumb: imgSrc});
  });


  const handleThumbClick = (index: number) => {
    api?.scrollTo(index);
  }

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-4xl max-h-[90vh] flex flex-col p-0 sm:rounded-lg">
        <ScrollArea className="h-full">
          <div className="p-4 sm:p-6">
            <DialogHeader>
              <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
                <div className="flex-grow order-2 sm:order-1">
                  <DialogTitle className="font-headline text-2xl sm:text-3xl mb-2">{project.title}</DialogTitle>
                  <DialogDescription>{project.description}</DialogDescription>
                </div>

                {project.softwareUsed && (
                    <Popover>
                        <PopoverTrigger asChild>
                            <Button variant="outline" className="ml-auto flex-shrink-0 order-1 sm:order-2 w-full sm:w-auto">
                                <ShieldCheck className="mr-2 h-4 w-4" /> Used Software
                            </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-80 sm:w-96">
                            <div className="grid gap-4">
                                <div className="space-y-2">
                                    <h4 className="font-medium leading-none font-headline">Software Used</h4>
                                    <p className="text-sm text-muted-foreground">
                                        The tools and technologies used to bring this project to life.
                                    </p>
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    {project.softwareUsed.modelingAndRender.length > 0 && (
                                        <div>
                                            <h5 className="font-semibold text-sm mb-2 text-primary/90 flex items-center gap-2"><Cpu size={16}/>Modelling & Render</h5>
                                            <ul className="space-y-1 list-disc list-inside">
                                                {project.softwareUsed.modelingAndRender.map(software => (
                                                    <li key={software} className="text-sm text-muted-foreground ml-2">
                                                        {software}
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>
                                    )}
                                    <div>
                                        {project.softwareUsed.postProduction.length > 0 && (
                                            <div>
                                                <h5 className="font-semibold text-sm mb-2 text-primary/90 flex items-center gap-2"><Paintbrush size={16}/>Post Production</h5>
                                                <ul className="space-y-1 list-disc list-inside">
                                                    {project.softwareUsed.postProduction.map(software => (
                                                        <li key={software} className="text-sm text-muted-foreground ml-2">
                                                            {software}
                                                        </li>
                                                    ))}
                                                </ul>
                                            </div>
                                        )}
                                        {project.softwareUsed.aiEnhanced.length > 0 && (
                                            <div className="mt-4">
                                                <h5 className="font-semibold text-sm mb-2 text-primary/90 flex items-center gap-2"><Wand2 size={16}/>AI Enhanced</h5>
                                                <ul className="space-y-1 list-disc list-inside">
                                                {project.softwareUsed.aiEnhanced.map(software => (
                                                    <li key={software} className="text-sm text-muted-foreground ml-2">
                                                        {software}
                                                    </li>
                                                ))}
                                                </ul>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </div>
                        </PopoverContent>
                    </Popover>
                )}
              </div>
            </DialogHeader>

            <div className="mt-6 space-y-4">
              {/* Main Carousel */}
              <Carousel setApi={setApi} className="w-full relative">
                <CarouselContent>
                  {allMedia.map((media, index) => (
                    <CarouselItem key={index}>
                      {media.type === 'image' ? (
                        <Image
                          src={media.src}
                          alt={`Project media ${index + 1} for ${project.title}`}
                          data-ai-hint={project.hint}
                          width={1200}
                          height={800}
                          className="w-full h-auto object-cover rounded-lg aspect-video"
                        />
                      ) : (
                        <video
                          src={media.src}
                          controls
                          autoPlay
                          muted
                          loop
                          className="w-full h-auto object-cover rounded-lg aspect-video bg-black"
                        >
                          Your browser does not support the video tag.
                        </video>
                      )}
                    </CarouselItem>
                  ))}
                </CarouselContent>
                <CarouselPrevious className="absolute left-2 top-1/2 -translate-y-1/2" />
                <CarouselNext className="absolute right-2 top-1/2 -translate-y-1/2" />
              </Carousel>
              
              {/* Thumbnail Gallery */}
              <div className="overflow-x-auto -mx-4 sm:-mx-6 px-4 sm:px-6">
                <div className="flex justify-start items-start gap-2 mt-2 pb-2">
                    {allMedia.map((media, index) => (
                        <button key={index} onClick={() => handleThumbClick(index)} className="p-1 flex-shrink-0 focus:outline-none focus:ring-2 focus:ring-primary rounded-lg">
                            <Image
                                src={media.thumb}
                                alt={`Thumbnail ${index + 1}`}
                                data-ai-hint={project.hint}
                                width={100}
                                height={75}
                                className={cn(
                                    "w-24 h-auto object-cover rounded-md cursor-pointer border-2 transition-all",
                                    current === index ? 'border-primary' : 'border-transparent opacity-60 hover:opacity-100'
                                )}
                            />
                        </button>
                    ))}
                </div>
              </div>
              
              {/* Mobile Close Button */}
              <div className="pt-4 text-center sm:hidden">
                <DialogClose asChild>
                  <Button variant="outline" size="lg">
                    <X className="mr-2 h-5 w-5" />
                    Close
                  </Button>
                </DialogClose>
              </div>

              {/* Download Button */}
              {project.downloadUrl && (
                  <div className="pt-4 text-center">
                      <Button asChild size="lg">
                          <a href={project.downloadUrl} download>
                              <Download className="mr-2 h-5 w-5" />
                              Get Main File
                          </a>
                      </Button>
                  </div>
              )}
            </div>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
