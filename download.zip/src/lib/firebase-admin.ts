
import { initializeApp, getApps, getApp, type App, cert, ServiceAccount } from 'firebase-admin/app';

const serviceAccount: ServiceAccount = {
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  clientEmail: process.env.FIREBASE_ADMIN_CLIENT_EMAIL,
  privateKey: process.env.FIREBASE_ADMIN_PRIVATE_KEY?.replace(/\\n/g, '\n'),
};

let adminApp: App | null = null;
let adminAppInitialized = false;

// Check if all required Firebase Admin config keys are present
const allAdminConfigKeysPresent = Object.values(serviceAccount).every(value => !!value);

export function initializeAdmin() {
    if (adminAppInitialized) return;

    if (allAdminConfigKeysPresent) {
        try {
            adminApp = !getApps().some(app => app.name === 'firebase-admin-app') 
                ? initializeApp({
                    credential: cert(serviceAccount)
                }, 'firebase-admin-app') 
                : getApp('firebase-admin-app');
            adminAppInitialized = true;
            console.log("Firebase Admin SDK initialized successfully.");
        } catch (error) {
            console.error("Firebase Admin SDK initialization failed:", error);
        }
    } else {
        console.warn("Firebase Admin environment variables are not fully configured.");
    }
}
