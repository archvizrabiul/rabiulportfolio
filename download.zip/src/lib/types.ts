
export type Project = {
  id: string;
  title: string;
  category: string;
  description: string;
  image: string; // Main thumbnail URL
  hint: string;
  video?: string; // Video URL
  gallery: string[]; // Array of image URLs
  downloadUrl?: string; // Main file URL
  softwareUsed: {
    modelingAndRender: string[];
    postProduction: string[];
    aiEnhanced: string[];
  };
  createdAt: string;
};

export type EducationItem = {
  institution: string;
  degree: string;
  period: string;
  focus: string;
};

export type CertificationItem = {
  program: string;
  field: string;
  period: string;
  skills: string;
};

export type WorkExperienceItem = {
  role: string;
  company: string;
  period: string;
  description: string;
};

export type Profile = {
  id: string;
  name: string;
  title: string;
  bio: string;
  profilePictureUrl: string;
  cvUrl: string;
  education: EducationItem[];
  certifications: CertificationItem[];
  experience: WorkExperienceItem[];
  siteTheme?: 'light' | 'dark' | 'system';
};

export type ContactMessage = {
  id: string;
  name: string;
  email: string;
  message: string;
  createdAt: string;
};

export type BlogPost = {
  id: string;
  title: string;
  slug: string;
  coverImageUrl: string;
  content: string; // Markdown content
  category: string;
  tags: string[];
  createdAt: string;
};

export type Category = {
  id: string;
  name: string;
  createdAt: string;
}

export type DownloadableVersion = {
    name: string;
    url: string;
};

export type Downloadable = {
    id: string;
    title: string;
    category: string;
    imageUrl: string;
    versions: DownloadableVersion[];
    createdAt: string;
};


// This represents the data structure for the project form
export type ProjectFormData = {
    title: string;
    category: string;
    description: string;
    image: string; // Main thumbnail URL
    hint: string;
    video?: string;
    gallery: string[];
    downloadUrl?: string;
    modelingAndRender: string; // Comma-separated
    postProduction: string; // Comma-separated
    aiEnhanced: string; // Comma-separated
};
