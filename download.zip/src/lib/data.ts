
import { collection, getDocs, doc, getDoc, orderBy, query, limit, where } from 'firebase/firestore';
import { db, firebaseInitialized } from './firebase';
import type { Project, Profile, ContactMessage, BlogPost, Category, Downloadable } from './types';
import { unstable_noStore as noStore } from 'next/cache';

const defaultProjects: Project[] = [
  {
    id: 'dummy-1',
    title: 'Modern Villa Exterior',
    category: 'Exterior',
    description: 'A photorealistic rendering of a modern villa, emphasizing the interplay of light, shadow, and natural materials. Created to provide a clear vision for the client before construction.',
    image: 'https://placehold.co/600x400.png',
    hint: 'modern villa',
    video: '',
    gallery: [
      'https://placehold.co/1200x800.png',
      'https://placehold.co/1200x800.png',
      'https://placehold.co/1200x800.png',
    ],
    downloadUrl: '',
    softwareUsed: {
      modelingAndRender: ['Revit', 'Corona'],
      postProduction: ['Photoshop'],
      aiEnhanced: [],
    },
    createdAt: new Date('2023-11-10T10:00:00Z').toISOString(),
  },
  {
    id: 'dummy-2',
    title: 'Cozy Living Room',
    category: 'Interior',
    description: 'An interior design visualization for a cozy and inviting living space. The project focuses on warm lighting, comfortable furniture, and a harmonious color palette.',
    image: 'https://placehold.co/600x400.png',
    hint: 'cozy livingroom',
    video: '',
    gallery: [
      'https://placehold.co/1200x800.png',
      'https://placehold.co/1200x800.png',
    ],
    downloadUrl: '',
    softwareUsed: {
      modelingAndRender: ['3ds Max', 'V-ray'],
      postProduction: ['Photoshop'],
      aiEnhanced: ['Midjourney'],
    },
    createdAt: new Date('2023-10-25T10:00:00Z').toISOString(),
  },
  {
    id: 'dummy-3',
    title: 'Structural 3D Model',
    category: '3D Model',
    description: 'A detailed structural 3D model of a commercial building, created for engineering analysis and clash detection. The model includes all major structural components.',
    image: 'https://placehold.co/600x400.png',
    hint: 'structural model',
    video: '',
    gallery: [],
    downloadUrl: '#',
    softwareUsed: {
      modelingAndRender: ['Revit', 'AutoCAD'],
      postProduction: [],
      aiEnhanced: [],
    },
    createdAt: new Date('2023-09-15T10:00:00Z').toISOString(),
  },
    {
    id: 'dummy-4',
    title: 'Urban Plaza Visualization',
    category: 'Exterior',
    description: 'A large-scale exterior visualization of a public urban plaza. This rendering was used in public consultations to showcase the proposed design and its impact on the urban environment.',
    image: 'https://placehold.co/600x400.png',
    hint: 'urban plaza',
    video: '',
    gallery: [
      'https://placehold.co/1200x800.png',
      'https://placehold.co/1200x800.png',
      'https://placehold.co/1200x800.png',
    ],
    downloadUrl: '',
    softwareUsed: {
      modelingAndRender: ['Revit', 'Enscape'],
      postProduction: ['Photoshop'],
      aiEnhanced: [],
    },
    createdAt: new Date('2023-08-20T10:00:00Z').toISOString(),
  },
];

const defaultBlogPosts: BlogPost[] = [
    {
        id: 'dummy-blog-1',
        title: 'The Future of Architectural Visualization with AI',
        slug: 'future-of-archviz-with-ai',
        coverImageUrl: 'https://placehold.co/1200x675.png',
        category: 'Technology',
        tags: ['AI', 'Archviz'],
        content: 'AI is not just a buzzword; it\'s a transformative force in architecture. This post explores how AI-powered tools are revolutionizing rendering, design conceptualization, and project workflows, leading to more efficient and creative outcomes.',
        createdAt: new Date('2023-12-01T10:00:00Z').toISOString(),
    },
    {
        id: 'dummy-blog-2',
        title: 'Mastering Photorealism in 3ds Max and Corona',
        slug: 'mastering-photorealism-3dsmax-corona',
        coverImageUrl: 'https://placehold.co/1200x675.png',
        category: 'Tutorial',
        tags: ['3ds Max', 'Corona', 'Photorealism'],
        content: 'Achieving photorealism requires a deep understanding of lighting, materials, and composition. In this tutorial, we walk through the essential techniques in 3ds Max and Corona Renderer to take your visualizations from good to breathtakingly realistic.',
        createdAt: new Date('2023-11-15T10:00:00Z').toISOString(),
    }
];

const defaultProfile: Profile = {
    id: 'main',
    name: 'Rabiul Hasan',
    title: 'Architectural Visualizer | AI Enthusiast',
    bio: 'Creative and detail-oriented Architectural Visualizer with a Diploma in Civil Engineering and certified training under the IsDB-BISEW IT Scholarship. Passionate about leveraging technology and AI to create stunning and realistic architectural representations.',
    profilePictureUrl: '/profile-picture.png',
    cvUrl: '/Rabiul_Hasan_CV.pdf',
    siteTheme: 'system',
    education: [
      {
        institution: 'Narsingdi Polytechnic Institute',
        degree: 'Diploma in Civil Engineering',
        period: '2018-2022',
        focus: 'Studied structural design, construction materials, and CAD; completed hands-on projects and site internships',
      },
    ],
    certifications: [
      {
        program: 'ISDB-BISEW IT SCHOLARSHIP',
        field: 'Architectural with Civil CAD',
        period: 'Oct, 2024 - Aug, 2025',
        skills: 'Trained in Revit, AutoCAD, 3ds Max, Photoshop, and MS Project with a focus on architectural drafting, 3D modeling, and civil engineering applications.',
      },
    ],
    experience: [
       {
        role: 'Junior Instructor - Civil Department',
        company: 'Narsingdi Institute of Science And Technology (NIST)',
        period: 'June, 2024 - Sep, 2024',
        description: 'Conducted classes on Structural Mechanics, Surveying, and Estimating for diploma-level Civil Engineering students. Delivered both theoretical and practical lessons, guided student projects, and provided academic support in lab and fieldwork. Assisted in curriculum implementation and promoted hands-on learning in civil engineering fundamentals.',
      },
      {
        role: 'Support Trainer',
        company: 'Global Computer Academy',
        period: 'Feb, 2021 - Jan, 2022',
        description: 'Assisted in training students in MS Office (Word, Excel, PowerPoint) and internet browsing. Supported lead trainers in class preparation, student guidance, and technical troubleshooting. Helped maintain a smooth learning environment during the post-pandemic transition.',
      },
    ],
  };

const defaultProjectCategories: Category[] = [
    { id: '1', name: 'Interior', createdAt: new Date().toISOString() },
    { id: '2', name: 'Exterior', createdAt: new Date().toISOString() },
    { id: '3', name: '3D Model', createdAt: new Date().toISOString() },
];

const defaultBlogCategories: Category[] = [
    { id: '1', name: 'Tutorial', createdAt: new Date().toISOString() },
    { id: '2', name: 'Showcase', createdAt: new Date().toISOString() },
    { id: '3', name: 'News', createdAt: new Date().toISOString() },
];

const defaultDownloadableItems: Downloadable[] = [
    {
        id: 'd1',
        title: 'Free 3ds Max Sofa Model',
        category: '3D Models',
        imageUrl: 'https://placehold.co/400x300.png',
        versions: [
            { name: '2020', url: '#' },
            { name: '2022', url: '#' },
            { name: 'FBX', url: '#' },
        ],
        createdAt: new Date().toISOString()
    },
    {
        id: 'd2',
        title: 'Modern Armchair',
        category: '3D Models',
        imageUrl: 'https://placehold.co/400x300.png',
        versions: [
            { name: 'Blender', url: '#' },
            { name: 'OBJ', url: '#' },
        ],
        createdAt: new Date().toISOString()
    },
    {
        id: 'd3',
        title: 'PBR Wood Textures',
        category: 'Textures',
        imageUrl: 'https://placehold.co/400x300.png',
        versions: [
            { name: '4K', url: '#' },
            { name: '8K', url: '#' },
        ],
        createdAt: new Date().toISOString()
    }
];

const defaultDownloadCategories: Category[] = [
    { id: '1', name: '3D Models', createdAt: new Date().toISOString() },
    { id: '2', name: 'Textures', createdAt: new Date().toISOString() },
    { id: '3', name: 'Software', createdAt: new Date().toISOString() },
];

// Fetch all projects, ordered by creation date
export async function getProjects(): Promise<Project[]> {
  noStore();
  if (!firebaseInitialized || !db) return defaultProjects;

  try {
    const projectsCol = collection(db, 'projects');
    const q = query(projectsCol, orderBy('createdAt', 'desc'));
    const projectsSnapshot = await getDocs(q);

    if (projectsSnapshot.empty) {
      console.log("No projects found in Firestore, using default projects.");
      return defaultProjects;
    }

    const projectList = projectsSnapshot.docs.map(doc => {
      const data = doc.data();
      const createdAt = data.createdAt?.toDate ? data.createdAt.toDate().toISOString() : new Date().toISOString();
      return {
        ...data,
        id: doc.id,
        createdAt: createdAt,
      };
    }) as Project[];
    return projectList;
  } catch (error) {
    console.error("Error fetching projects: ", error);
    return defaultProjects;
  }
}

// Fetch a limited number of projects for the homepage
export async function getHomepageProjects(count: number = 6): Promise<Project[]> {
   noStore();
   if (!firebaseInitialized || !db) return defaultProjects.slice(0, count);

   try {
    const projectsCol = collection(db, 'projects');
    const q = query(projectsCol, orderBy('createdAt', 'desc'), limit(count));
    const projectsSnapshot = await getDocs(q);

    if (projectsSnapshot.empty) {
        console.log("No projects found in Firestore, using default homepage projects.");
        return defaultProjects.slice(0, count);
    }

    const projectList = projectsSnapshot.docs.map(doc => {
      const data = doc.data();
       const createdAt = data.createdAt?.toDate ? data.createdAt.toDate().toISOString() : new Date().toISOString();
      return {
        ...data,
        id: doc.id,
        createdAt: createdAt,
      };
    }) as Project[];
    return projectList;
  } catch (error) {
    console.error("Error fetching homepage projects: ", error);
    return defaultProjects.slice(0, count);
  }
}


// Fetch profile information
export async function getProfile(): Promise<Profile> {
  noStore();
  if (!firebaseInitialized || !db) return defaultProfile;
  
  try {
    const profileDocRef = doc(db, 'profile', 'main');
    const profileDoc = await getDoc(profileDocRef);

    if (profileDoc.exists()) {
      // Combine fetched data with defaults to ensure all fields are present
      const data = profileDoc.data();
      const finalProfile = {
        ...defaultProfile,
        ...data,
        id: profileDoc.id,
        education: data.education || defaultProfile.education,
        certifications: data.certifications || defaultProfile.certifications,
        experience: data.experience || defaultProfile.experience,
        siteTheme: data.siteTheme || 'system',
      } as Profile;

      // Validate and correct invalid Google Drive folder URLs
      if (finalProfile.profilePictureUrl && finalProfile.profilePictureUrl.includes('drive.google.com/drive/folders')) {
         console.warn('Invalid profile picture URL detected. Falling back to default.');
        finalProfile.profilePictureUrl = defaultProfile.profilePictureUrl;
      }
      if (finalProfile.cvUrl && finalProfile.cvUrl.includes('drive.google.com/drive/folders')) {
         console.warn('Invalid CV URL detected. Falling back to default.');
        finalProfile.cvUrl = defaultProfile.cvUrl;
      }
      
      return finalProfile;

    } else {
      console.log("No profile document found! Using default profile.");
      return defaultProfile;
    }
  } catch (error) {
    console.error("Error fetching profile, using default profile: ", error);
    // Return default profile on any error to prevent site crash
    return defaultProfile;
  }
}

// Fetch all contact messages
export async function getContactMessages(): Promise<ContactMessage[]> {
  noStore();
  if (!firebaseInitialized || !db) return [];
  try {
    const messagesCol = collection(db, 'contactMessages');
    const q = query(messagesCol, orderBy('createdAt', 'desc'));
    const messagesSnapshot = await getDocs(q);
    const messageList = messagesSnapshot.docs.map(doc => {
      const data = doc.data();
      const createdAt = data.createdAt?.toDate ? data.createdAt.toDate().toISOString() : new Date().toISOString();
      return {
        ...data,
        id: doc.id,
        createdAt: createdAt,
      };
    }) as ContactMessage[];
    return messageList;
  } catch (error) {
    console.error("Error fetching contact messages: ", error);
    return [];
  }
}

// Fetch all blog posts
export async function getBlogPosts(): Promise<BlogPost[]> {
  noStore();
  if (!firebaseInitialized || !db) return defaultBlogPosts;
  try {
    const postsCol = collection(db, 'blogPosts');
    const q = query(postsCol, orderBy('createdAt', 'desc'));
    const postsSnapshot = await getDocs(q);
     if (postsSnapshot.empty) {
      console.log("No blog posts found in Firestore, using default posts.");
      return defaultBlogPosts;
    }
    const postList = postsSnapshot.docs.map(doc => {
      const data = doc.data();
      const createdAt = data.createdAt?.toDate ? data.createdAt.toDate().toISOString() : new Date().toISOString();
      return {
        ...data,
        id: doc.id,
        createdAt: createdAt,
      };
    }) as BlogPost[];
    return postList;
  } catch (error) {
    console.error("Error fetching blog posts: ", error);
    return defaultBlogPosts;
  }
}

// Fetch a single blog post by its slug
export async function getBlogPostBySlug(slug: string): Promise<BlogPost | null> {
  noStore();
  if (!firebaseInitialized || !db) {
      const defaultPost = defaultBlogPosts.find(p => p.slug === slug);
      return defaultPost || null;
  }

  try {
    const postsCol = collection(db, 'blogPosts');
    const q = query(postsCol, where('slug', '==', slug), limit(1));
    const postSnapshot = await getDocs(q);
    if (postSnapshot.empty) {
       // Check if the slug matches a default blog post
      const defaultPost = defaultBlogPosts.find(p => p.slug === slug);
      if (defaultPost) {
        console.log(`No blog post with slug ${slug} found in Firestore, using default post.`);
        return defaultPost;
      }
      return null;
    }
    const postDoc = postSnapshot.docs[0];
    const data = postDoc.data();
    const createdAt = data.createdAt?.toDate ? data.createdAt.toDate().toISOString() : new Date().toISOString();
    return { 
      ...data,
      id: postDoc.id, 
      createdAt: createdAt,
    } as BlogPost;
  } catch (error) {
    console.error(`Error fetching blog post with slug ${slug}:`, error);
    // Fallback to default posts on error as well
    const defaultPost = defaultBlogPosts.find(p => p.slug === slug);
    return defaultPost || null;
  }
}

// Fetch categories for projects or blog posts
export async function getCategories(collectionName: 'projectCategories' | 'blogCategories' | 'downloadCategories'): Promise<Category[]> {
  noStore();
  let defaultCategories;
  switch (collectionName) {
    case 'projectCategories':
        defaultCategories = defaultProjectCategories;
        break;
    case 'blogCategories':
        defaultCategories = defaultBlogCategories;
        break;
    case 'downloadCategories':
        defaultCategories = defaultDownloadCategories;
        break;
    default:
        defaultCategories = [];
  }


  if (!firebaseInitialized || !db) return defaultCategories;

  try {
    const catCol = collection(db, collectionName);
    const q = query(catCol, orderBy('createdAt', 'asc'));
    const catSnapshot = await getDocs(q);

    if (catSnapshot.empty) {
      return defaultCategories;
    }

    return catSnapshot.docs.map(doc => {
      const data = doc.data();
      return {
        id: doc.id,
        name: data.name,
        createdAt: data.createdAt?.toDate ? data.createdAt.toDate().toISOString() : new Date().toISOString(),
      };
    }) as Category[];
  } catch (error) {
    console.error(`Error fetching ${collectionName}: `, error);
    return defaultCategories;
  }
}

// Fetch all downloadable items
export async function getDownloadables(): Promise<Downloadable[]> {
    noStore();
    if (!firebaseInitialized || !db) return defaultDownloadableItems;

    try {
        const itemsCol = collection(db, 'downloadables');
        const q = query(itemsCol, orderBy('createdAt', 'desc'));
        const itemsSnapshot = await getDocs(q);

        if (itemsSnapshot.empty) {
            console.log("No downloadable items found in Firestore, using default items.");
            return defaultDownloadableItems;
        }

        const itemList = itemsSnapshot.docs.map(doc => {
            const data = doc.data();
            return {
                ...data,
                id: doc.id,
                createdAt: data.createdAt?.toDate ? data.createdAt.toDate().toISOString() : new Date().toISOString(),
            };
        }) as Downloadable[];
        return itemList;
    } catch (error) {
        console.error("Error fetching downloadable items: ", error);
        return defaultDownloadableItems;
    }
}

    

    