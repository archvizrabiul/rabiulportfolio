import { getContactMessages } from "@/lib/data";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { formatDistanceToNow } from 'date-fns';

export default async function MessagesPage() {
  const messages = await getContactMessages();

  return (
    <Card>
      <CardHeader>
        <CardTitle>Contact Messages</CardTitle>
        <CardDescription>
          You have received {messages.length} message{messages.length !== 1 ? 's' : ''}.
        </CardDescription>
      </CardHeader>
      <CardContent>
        {messages.length === 0 ? (
          <p className="text-muted-foreground">You have no messages yet.</p>
        ) : (
          <Accordion type="multiple" className="w-full">
            {messages.map((message) => (
              <AccordionItem value={message.id} key={message.id}>
                <AccordionTrigger>
                  <div className="flex justify-between w-full pr-4">
                    <span className="font-medium text-left">{message.name} <span className="font-normal text-muted-foreground">&lt;{message.email}&gt;</span></span>
                    <span className="text-sm text-muted-foreground text-right">
                      {message.createdAt ? formatDistanceToNow(new Date(message.createdAt), { addSuffix: true }) : 'N/A'}
                    </span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="whitespace-pre-wrap text-foreground/90">
                  {message.message}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        )}
      </CardContent>
      {messages.length > 0 && (
         <CardFooter>
            <p className="text-xs text-muted-foreground">Messages are stored in Firestore and also sent to your email.</p>
         </CardFooter>
      )}
    </Card>
  );
}
