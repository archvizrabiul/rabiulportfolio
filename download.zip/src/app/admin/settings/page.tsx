
import { Card, CardDescription, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { CategoryManager } from "@/app/admin/settings/category-manager";
import { getCategories } from "@/lib/data";

export default async function SettingsPage() {
  const [projectCategories, blogCategories, downloadCategories] = await Promise.all([
    getCategories("projectCategories"),
    getCategories("blogCategories"),
    getCategories("downloadCategories"),
  ]);

  return (
    <div className="space-y-6">
      <Card>
          <CardHeader>
              <CardTitle>Settings</CardTitle>
              <CardDescription>Manage application-wide settings like categories for your projects, blog, and downloads.</CardDescription>
          </CardHeader>
      </Card>
      
      <CategoryManager 
          title="Project Categories"
          description="Manage the categories used for filtering projects on your portfolio."
          collectionName="projectCategories"
          initialCategories={projectCategories}
      />

      <CategoryManager 
          title="Blog Categories"
          description="Manage the categories used for organizing your blog posts."
          collectionName="blogCategories"
          initialCategories={blogCategories}
      />

      <CategoryManager 
          title="Download Categories"
          description="Manage the categories for the download directory."
          collectionName="downloadCategories"
          initialCategories={downloadCategories}
      />
    </div>
  );
}
