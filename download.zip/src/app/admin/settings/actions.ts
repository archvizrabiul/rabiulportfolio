
'use server';

import { z } from 'zod';
import { revalidatePath } from 'next/cache';
import { db, firebaseInitialized } from '@/lib/firebase';
import { doc, addDoc, updateDoc, deleteDoc, collection, serverTimestamp } from 'firebase/firestore';

const CategorySchema = z.object({
  name: z.string().min(1, "Category name is required."),
});

type CategoryState = {
  message?: string | null;
  success?: boolean;
  errors?: {
    name?: string[];
  };
};

export async function upsertCategoryAction(
  prevState: CategoryState,
  formData: FormData
): Promise<CategoryState> {
  if (!firebaseInitialized || !db) {
    return {
      message: 'Database not configured. Cannot save category.',
      success: false,
    };
  }

  const categoryId = formData.get('categoryId') as string | null;
  const collectionName = formData.get('collectionName') as string;

  if (!['projectCategories', 'blogCategories', 'downloadCategories'].includes(collectionName)) {
      return { message: 'Invalid category type.', success: false };
  }

  const validatedFields = CategorySchema.safeParse({
    name: formData.get('name'),
  });

  if (!validatedFields.success) {
    return {
      message: 'Validation failed.',
      errors: validatedFields.error.flatten().fieldErrors,
      success: false,
    };
  }

  try {
    if (categoryId) {
      const catRef = doc(db, collectionName, categoryId);
      await updateDoc(catRef, { name: validatedFields.data.name });
    } else {
      await addDoc(collection(db, collectionName), {
        name: validatedFields.data.name,
        createdAt: serverTimestamp(),
      });
    }

    revalidatePath('/admin/settings');
    revalidatePath('/admin/dashboard');
    revalidatePath('/admin/blog');
    revalidatePath('/admin/downloads');
    revalidatePath('/');
    revalidatePath('/portfolio');
    revalidatePath('/blog');
    revalidatePath('/downloads');


    return {
      message: `Category successfully ${categoryId ? 'updated' : 'created'}.`,
      success: true,
    };
  } catch (error) {
    console.error('Error upserting category:', error);
    return {
      message: `An error occurred: ${error instanceof Error ? error.message : 'Unknown error'}.`,
      success: false,
    };
  }
}

export async function deleteCategoryAction(
    collectionName: string, 
    categoryId: string
): Promise<{ success: boolean; message: string }> {
  if (!firebaseInitialized || !db) {
    return { success: false, message: 'Database not configured.' };
  }
   if (!['projectCategories', 'blogCategories', 'downloadCategories'].includes(collectionName)) {
      return { success: false, message: 'Invalid category type.' };
  }
  if (!categoryId) {
    return { success: false, message: 'Category ID is required.' };
  }

  try {
    const catRef = doc(db, collectionName, categoryId);
    await deleteDoc(catRef);

    revalidatePath('/admin/settings');
    revalidatePath('/admin/dashboard');
    revalidatePath('/admin/blog');
    revalidatePath('/admin/downloads');
    revalidatePath('/');
    revalidatePath('/portfolio');
    revalidatePath('/blog');
    revalidatePath('/downloads');

    return { success: true, message: 'Category deleted successfully.' };
  } catch (error) {
    console.error('Error deleting category:', error);
    return {
      success: false,
      message: `Failed to delete category: ${error instanceof Error ? error.message : 'Unknown error'}`,
    };
  }
}
