
'use client';

import { useState, useCallback } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { PlusCircle } from 'lucide-react';
import type { Project } from '@/lib/types';
import { ProjectForm } from './project-form';

type ProjectDialogProps = {
  mode: 'add' | 'edit';
  project?: Project;
  categories: string[];
  children?: React.ReactNode;
};

export function ProjectDialog({ mode, project, categories, children }: ProjectDialogProps) {
  const [open, setOpen] = useState(false);

  const handleSuccess = useCallback(() => {
    setOpen(false);
  }, []);

  const triggerButton =
    mode === 'add' ? (
      <Button>
        <PlusCircle className="mr-2 h-4 w-4" /> Add Project
      </Button>
    ) : (
      <div className="w-full">{children}</div>
    );

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{triggerButton}</DialogTrigger>
      <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{mode === 'add' ? 'Add New Project' : 'Edit Project'}</DialogTitle>
          <DialogDescription>
            Fill out the details below to {mode} your project. Click save when you're done.
          </DialogDescription>
        </DialogHeader>
        <ProjectForm
          mode={mode}
          project={project}
          onSuccess={handleSuccess}
          categories={categories}
        />
      </DialogContent>
    </Dialog>
  );
}
