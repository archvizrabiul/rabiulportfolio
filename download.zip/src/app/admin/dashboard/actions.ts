
'use server';

import { z } from 'zod';
import { revalidatePath } from 'next/cache';
import { db, storage, firebaseInitialized } from '@/lib/firebase';
import { doc, addDoc, updateDoc, deleteDoc, collection, serverTimestamp } from 'firebase/firestore';
import { deleteObject, ref } from 'firebase/storage';
import type { Project } from '@/lib/types';

const ProjectSchema = z.object({
  title: z.string().min(1, "Title is required."),
  category: z.string().min(1, "Category is required."),
  description: z.string().min(1, "Description is required."),
  image: z.string().url("A valid image URL is required.").or(z.literal('')),
  hint: z.string().optional(),
  video: z.string().url("A valid video URL is required.").optional().or(z.literal('')),
  gallery: z.array(z.string().url()).optional(),
  downloadUrl: z.string().url("A valid download URL is required.").optional().or(z.literal('')),
  modelingAndRender: z.string().optional(),
  postProduction: z.string().optional(),
  aiEnhanced: z.string().optional(),
});

type ProjectState = {
  message?: string | null;
  success?: boolean;
  errors?: {
    [key: string]: string[] | undefined;
  };
};

function formatSoftware(input?: string): string[] {
    if (!input) return [];
    return input.split(',').map(s => s.trim()).filter(Boolean);
}

export async function upsertProjectAction(
  prevState: ProjectState,
  formData: FormData
): Promise<ProjectState> {
  if (!firebaseInitialized || !db) {
    return {
      message: 'Database not configured. Cannot save project.',
      success: false,
    };
  }
  
  const projectId = formData.get('projectId') as string | null;
  
  // Handle gallery images
  const galleryUrls = formData.getAll('gallery').map(String).filter(Boolean);

  const rawData = {
    title: formData.get('title'),
    category: formData.get('category'),
    description: formData.get('description'),
    image: formData.get('image'),
    hint: formData.get('hint'),
    video: formData.get('video'),
    gallery: galleryUrls,
    downloadUrl: formData.get('downloadUrl'),
    modelingAndRender: formData.get('modelingAndRender'),
    postProduction: formData.get('postProduction'),
    aiEnhanced: formData.get('aiEnhanced'),
  }

  // Server-side validation
  if (!rawData.image) {
      return {
          message: 'A main image is required.',
          success: false,
      };
  }

  const validatedFields = ProjectSchema.safeParse(rawData);

  if (!validatedFields.success) {
    return {
      message: 'Validation failed.',
      errors: validatedFields.error.flatten().fieldErrors,
      success: false,
    };
  }

  const data = validatedFields.data;

  const projectData = {
    title: data.title,
    category: data.category,
    description: data.description,
    image: data.image,
    hint: data.hint || '',
    video: data.video || '',
    gallery: data.gallery || [],
    downloadUrl: data.downloadUrl || '',
    softwareUsed: {
      modelingAndRender: formatSoftware(data.modelingAndRender),
      postProduction: formatSoftware(data.postProduction),
      aiEnhanced: formatSoftware(data.aiEnhanced),
    },
  };

  try {
    if (projectId) {
      // Update existing project
      const projectRef = doc(db, 'projects', projectId);
      await updateDoc(projectRef, projectData);
    } else {
      // Add new project
      await addDoc(collection(db, 'projects'), {
        ...projectData,
        createdAt: serverTimestamp(),
      });
    }

    revalidatePath('/admin/dashboard');
    revalidatePath('/');
    revalidatePath('/portfolio');

    return {
      message: `Project successfully ${projectId ? 'updated' : 'created'}.`,
      success: true,
    };
  } catch (error) {
    console.error('Error upserting project:', error);
    return {
      message: `An error occurred: ${error instanceof Error ? error.message : 'Unknown error'}.`,
      success: false,
    };
  }
}

export async function deleteProjectAction(projectId: string): Promise<{ success: boolean; message: string }> {
  if (!firebaseInitialized || !db) {
    return { success: false, message: 'Database not configured. Cannot delete project.' };
  }

  if (!projectId) {
    return { success: false, message: 'Project ID is required.' };
  }

  try {
    const projectRef = doc(db, 'projects', projectId);
    await deleteDoc(projectRef);

    // Note: This does not delete associated files from Firebase Storage.
    // Implementing that would require storing full storage paths in Firestore.

    revalidatePath('/admin/dashboard');
    revalidatePath('/');
    revalidatePath('/portfolio');

    return { success: true, message: 'Project deleted successfully.' };
  } catch (error) {
    console.error('Error deleting project:', error);
    return {
      success: false,
      message: `Failed to delete project: ${error instanceof Error ? error.message : 'Unknown error'}`,
    };
  }
}
