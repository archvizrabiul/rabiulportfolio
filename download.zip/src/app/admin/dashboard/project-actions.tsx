
'use client';

import { MoreHorizontal } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { ProjectDialog } from "./project-dialog";
import { DeleteProjectDialog } from './delete-project-dialog';
import type { Project } from '@/lib/types';

type ProjectActionsProps = {
    project: Project;
    categories: string[];
};

export function ProjectActions({ project, categories }: ProjectActionsProps) {
    return (
        <DropdownMenu>
            <DropdownMenuTrigger aria-haspopup="true">
                <MoreHorizontal className="h-4 w-4" />
                <span className="sr-only">Toggle menu</span>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                <ProjectDialog mode="edit" project={project} categories={categories}>
                    <DropdownMenuItem onSelect={(e) => e.preventDefault()}>Edit</DropdownMenuItem>
                </ProjectDialog>
                <DeleteProjectDialog projectId={project.id} projectTitle={project.title}>
                    <DropdownMenuItem onSelect={(e) => e.preventDefault()} className="text-destructive focus:text-destructive focus:bg-destructive/10">
                        Delete
                    </DropdownMenuItem>
                </DeleteProjectDialog>
            </DropdownMenuContent>
        </DropdownMenu>
    );
}
