
'use client';

import { useEffect, useTransition, useMemo } from 'react';
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useFormState } from 'react-dom';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { upsertProjectAction } from './actions';
import type { Project } from '@/lib/types';
import { Trash2, PlusCircle } from 'lucide-react';

const ProjectFormSchema = z.object({
  title: z.string().min(1, "Title is required."),
  category: z.string().min(1, "Category is required."),
  description: z.string().min(1, "Description is required."),
  image: z.string().url("A valid main image URL is required.").or(z.literal('')),
  hint: z.string().optional(),
  video: z.string().url("A valid video URL is required.").optional().or(z.literal('')),
  gallery: z.array(z.object({ url: z.string().url("Each gallery entry must be a valid URL.") })).optional(),
  downloadUrl: z.string().url("A valid download URL is required.").optional().or(z.literal('')),
  modelingAndRender: z.string().optional(),
  postProduction: z.string().optional(),
  aiEnhanced: z.string().optional(),
});

type FormValues = z.infer<typeof ProjectFormSchema>;

type ProjectFormProps = {
  mode: 'add' | 'edit';
  project?: Project;
  onSuccess: () => void;
  categories: string[];
};

export function ProjectForm({ mode, project, onSuccess, categories }: ProjectFormProps) {
  const [state, formAction] = useFormState(upsertProjectAction, {
    message: null,
    success: false,
  });
  const [isPending, startTransition] = useTransition();
  const { toast } = useToast();

  const defaultValues = useMemo(() => ({
    title: project?.title || '',
    category: project?.category || '',
    description: project?.description || '',
    image: project?.image || '',
    hint: project?.hint || '',
    video: project?.video || '',
    gallery: project?.gallery?.map(url => ({ url })) || [],
    downloadUrl: project?.downloadUrl || '',
    modelingAndRender: project?.softwareUsed?.modelingAndRender.join(', ') || '',
    postProduction: project?.softwareUsed?.postProduction.join(', ') || '',
    aiEnhanced: project?.softwareUsed?.aiEnhanced.join(', ') || '',
  }), [project]);

  const form = useForm<FormValues>({
    resolver: zodResolver(ProjectFormSchema),
    defaultValues,
  });
  
  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: 'gallery'
  });

  useEffect(() => {
    if (state.message) {
      if (state.success) {
        toast({ title: 'Success!', description: state.message });
        onSuccess();
      } else {
        toast({ title: 'Error', description: state.message || "An unknown error occurred.", variant: 'destructive' });
      }
    }
  }, [state, onSuccess, toast]);
  
  const handleSubmit = (data: FormValues) => {
    startTransition(() => {
      const formData = new FormData();
      
      // Manually create a plain object from form data
      const plainData: {[key: string]: any} = { ...data };

      // Convert gallery array of objects to array of strings
      if (plainData.gallery) {
        plainData.gallery = plainData.gallery.map(item => item.url).filter(Boolean);
      } else {
        plainData.gallery = [];
      }
      
      // Append all data to formData
      for (const key in plainData) {
        const value = plainData[key];
        if (key === 'gallery' && Array.isArray(value)) {
            value.forEach(url => formData.append('gallery', url));
        } else if (value !== undefined && value !== null && value !== '') {
            formData.append(key, value as string);
        }
      }
  
      if (mode === 'edit' && project?.id) {
          formData.append('projectId', project.id);
      }
      
      formAction(formData);
    });
  }

  return (
    <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="title">Project Title</Label>
          <Input id="title" {...form.register('title')} />
          {form.formState.errors.title && <p className="text-sm text-destructive">{form.formState.errors.title.message}</p>}
        </div>
        <div className="space-y-2">
          <Label htmlFor="category">Category</Label>
          <Select onValueChange={(value) => form.setValue('category', value, { shouldValidate: true })} defaultValue={form.getValues('category')}>
            <SelectTrigger id="category">
              <SelectValue placeholder="Select a category" />
            </SelectTrigger>
            <SelectContent>
              {categories.map(filter => (
                <SelectItem key={filter} value={filter}>{filter}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          {form.formState.errors.category && <p className="text-sm text-destructive">{form.formState.errors.category.message}</p>}
        </div>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Textarea id="description" {...form.register('description')} rows={4} />
        {form.formState.errors.description && <p className="text-sm text-destructive">{form.formState.errors.description.message}</p>}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
            <Label htmlFor="image">Main Image URL</Label>
            <Input id="image" {...form.register('image')} placeholder="https://example.com/main.png" />
            {form.formState.errors.image && <p className="text-sm text-destructive mt-1">{form.formState.errors.image.message}</p>}
        </div>
        <div className="space-y-2">
          <Label htmlFor="video">Main Video URL (Optional)</Label>
          <Input id="video" {...form.register('video')} placeholder="https://example.com/video.mp4" />
        </div>
      </div>

      <div className="space-y-2">
        <Label>Image Gallery URLs</Label>
        <div className="space-y-2">
          {fields.map((field, index) => (
            <div key={field.id} className="flex items-center gap-2">
              <Input
                {...form.register(`gallery.${index}.url`)}
                placeholder="https://example.com/gallery-image.png"
                className="flex-grow"
              />
              <Button type="button" variant="destructive" size="icon" onClick={() => remove(index)}>
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          ))}
        </div>
        <Button type="button" variant="outline" size="sm" onClick={() => append({ url: '' })}>
          <PlusCircle className="mr-2 h-4 w-4" /> Add Image URL
        </Button>
        {form.formState.errors.gallery && <p className="text-sm text-destructive mt-1">{form.formState.errors.gallery.message || form.formState.errors.gallery.root?.message}</p>}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
         <div className="space-y-2">
            <Label htmlFor="downloadUrl">Main File URL (PDF, ZIP, etc.) (Optional)</Label>
            <Input id="downloadUrl" {...form.register('downloadUrl')} placeholder="https://example.com/file.zip" />
            {form.formState.errors.downloadUrl && <p className="text-sm text-destructive">{form.formState.errors.downloadUrl.message}</p>}
        </div>
        <div className="space-y-2">
          <Label htmlFor="hint">AI Image Hint (Optional)</Label>
          <Input id="hint" {...form.register('hint')} placeholder="e.g., modern interior" />
        </div>
      </div>
      
      <div className="space-y-4">
        <h3 className="text-lg font-medium">Software Used (comma-separated)</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
                <Label htmlFor="modelingAndRender">Modeling & Render</Label>
                <Input id="modelingAndRender" {...form.register('modelingAndRender')} placeholder="Revit, Corona"/>
            </div>
             <div className="space-y-2">
                <Label htmlFor="postProduction">Post Production</Label>
                <Input id="postProduction" {...form.register('postProduction')} placeholder="Photoshop" />
            </div>
             <div className="space-y-2">
                <Label htmlFor="aiEnhanced">AI Enhanced</Label>
                <Input id="aiEnhanced" {...form.register('aiEnhanced')} placeholder="Midjourney" />
            </div>
        </div>
      </div>
      
      <div className="flex justify-end gap-2">
        <Button type="submit" disabled={isPending}>
          {isPending ? (mode === 'add' ? 'Adding...' : 'Saving...') : 'Save Project'}
        </Button>
      </div>
    </form>
  );
}
