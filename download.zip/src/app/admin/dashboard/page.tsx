
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import Image from "next/image";
import { getProjects, getCategories } from "@/lib/data";
import { ProjectDialog } from "./project-dialog";
import { Badge } from "@/components/ui/badge";
import { ProjectActions } from "./project-actions";

export default async function DashboardPage() {
  const [projects, categories] = await Promise.all([
      getProjects(),
      getCategories('projectCategories')
  ]);

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
            <div>
                <CardTitle>Projects</CardTitle>
                <CardDescription>Manage your {projects.length} portfolio projects.</CardDescription>
            </div>
            <ProjectDialog mode="add" categories={categories.map(c => c.name)} />
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="hidden w-[100px] sm:table-cell">
                <span className="sr-only">Image</span>
              </TableHead>
              <TableHead>Title</TableHead>
              <TableHead>Category</TableHead>
              <TableHead className="hidden md:table-cell">Created At</TableHead>
              <TableHead>
                <span className="sr-only">Actions</span>
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {projects.map((project) => (
              <TableRow key={project.id}>
                <TableCell className="hidden sm:table-cell">
                  <Image
                    alt={project.title}
                    className="aspect-square rounded-md object-cover"
                    data-ai-hint={project.hint}
                    height="64"
                    src={project.image}
                    width="64"
                  />
                </TableCell>
                <TableCell className="font-medium">{project.title}</TableCell>
                <TableCell>
                  <Badge variant="outline">{project.category}</Badge>
                </TableCell>
                <TableCell className="hidden md:table-cell">
                  {project.createdAt ? new Date(project.createdAt).toLocaleDateString() : ''}
                </TableCell>
                <TableCell>
                  <ProjectActions project={project} categories={categories.map(c => c.name)} />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
