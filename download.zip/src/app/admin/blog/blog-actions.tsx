
'use client';

import { MoreHorizontal } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { PostDialog } from "./post-dialog";
import { DeletePostDialog } from './delete-post-dialog';
import type { BlogPost } from '@/lib/types';

type BlogActionsProps = {
    post: BlogPost;
    categories: string[];
};

export function BlogActions({ post, categories }: BlogActionsProps) {
    return (
        <DropdownMenu>
            <DropdownMenuTrigger aria-haspopup="true">
                <MoreHorizontal className="h-4 w-4" />
                <span className="sr-only">Toggle menu</span>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                <PostDialog mode="edit" post={post} categories={categories}>
                    <DropdownMenuItem onSelect={(e) => e.preventDefault()}>Edit</DropdownMenuItem>
                </PostDialog>
                <DeletePostDialog postId={post.id} postTitle={post.title}>
                    <DropdownMenuItem onSelect={(e) => e.preventDefault()} className="text-destructive focus:text-destructive focus:bg-destructive/10">
                        Delete
                    </DropdownMenuItem>
                </DeletePostDialog>
            </DropdownMenuContent>
        </DropdownMenu>
    );
}
