
'use client';

import { useState, useCallback } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { PlusCircle } from 'lucide-react';
import type { BlogPost } from '@/lib/types';
import { PostForm } from '@/app/admin/blog/post-form';

type PostDialogProps = {
  mode: 'add' | 'edit';
  post?: BlogPost;
  categories: string[];
  children?: React.ReactNode;
};

export function PostDialog({ mode, post, categories, children }: PostDialogProps) {
  const [open, setOpen] = useState(false);

  const handleSuccess = useCallback(() => {
    setOpen(false);
  }, []);

  const triggerButton =
    mode === 'add' ? (
      <Button>
        <PlusCircle className="mr-2 h-4 w-4" /> Add Post
      </Button>
    ) : (
      <div className="w-full">{children}</div>
    );

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{triggerButton}</DialogTrigger>
      <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{mode === 'add' ? 'Add New Post' : 'Edit Post'}</DialogTitle>
          <DialogDescription>
            Fill out the details below to {mode} your post. Click save when you're done.
          </DialogDescription>
        </DialogHeader>
        <PostForm
          mode={mode}
          post={post}
          onSuccess={handleSuccess}
          categories={categories}
        />
      </DialogContent>
    </Dialog>
  );
}
