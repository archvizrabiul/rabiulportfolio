
'use server';

import { z } from 'zod';
import { revalidatePath } from 'next/cache';
import { db, firebaseInitialized } from '@/lib/firebase';
import { doc, addDoc, updateDoc, deleteDoc, collection, serverTimestamp } from 'firebase/firestore';
import { generateSlug } from '@/lib/utils';

const PostSchema = z.object({
  title: z.string().min(1, "Title is required."),
  slug: z.string().min(1, "Slug is required."),
  content: z.string().min(1, "Content is required."),
  coverImageUrl: z.string().url("A valid image URL is required."),
  category: z.string().min(1, "Category is required."),
  tags: z.string().optional(),
});

type PostState = {
  message?: string | null;
  success?: boolean;
  errors?: {
    [key: string]: string[] | undefined;
  };
};

function formatTags(input?: string): string[] {
    if (!input) return [];
    return input.split(',').map(s => s.trim()).filter(Boolean);
}

export async function upsertPostAction(
  prevState: PostState,
  formData: FormData
): Promise<PostState> {
  if (!firebaseInitialized || !db) {
    return {
      message: 'Database not configured. Cannot save post.',
      success: false,
    };
  }

  const postId = formData.get('postId') as string | null;
  
  const rawData = {
    title: formData.get('title'),
    slug: formData.get('slug'),
    content: formData.get('content'),
    coverImageUrl: formData.get('coverImageUrl'),
    category: formData.get('category'),
    tags: formData.get('tags'),
  }

  const validatedFields = PostSchema.safeParse(rawData);

  if (!validatedFields.success) {
    return {
      message: 'Validation failed.',
      errors: validatedFields.error.flatten().fieldErrors,
      success: false,
    };
  }

  const data = validatedFields.data;
  const postData = {
    ...data,
    tags: formatTags(data.tags),
  }

  try {
    if (postId) {
      // Update existing post
      const postRef = doc(db, 'blogPosts', postId);
      await updateDoc(postRef, postData);
    } else {
      // Add new post
      await addDoc(collection(db, 'blogPosts'), {
        ...postData,
        createdAt: serverTimestamp(),
      });
    }

    revalidatePath('/admin/blog');
    revalidatePath('/blog');
    revalidatePath(`/blog/${data.slug}`);
    revalidatePath('/'); // Revalidate homepage for latest posts section

    return {
      message: `Post successfully ${postId ? 'updated' : 'created'}.`,
      success: true,
    };
  } catch (error) {
    console.error('Error upserting post:', error);
    return {
      message: `An error occurred: ${error instanceof Error ? error.message : 'Unknown error'}.`,
      success: false,
    };
  }
}

export async function deletePostAction(postId: string): Promise<{ success: boolean; message: string }> {
  if (!firebaseInitialized || !db) {
    return { success: false, message: 'Database not configured. Cannot delete post.' };
  }
  if (!postId) {
    return { success: false, message: 'Post ID is required.' };
  }

  try {
    const postRef = doc(db, 'blogPosts', postId);
    await deleteDoc(postRef);

    revalidatePath('/admin/blog');
    revalidatePath('/blog');
    revalidatePath('/'); // Revalidate homepage for latest posts section

    return { success: true, message: 'Post deleted successfully.' };
  } catch (error) {
    console.error('Error deleting post:', error);
    return {
      success: false,
      message: `Failed to delete post: ${error instanceof Error ? error.message : 'Unknown error'}`,
    };
  }
}
