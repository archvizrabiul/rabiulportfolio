
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import Image from "next/image";
import { getBlogPosts, getCategories } from "@/lib/data";
import { PostDialog } from "@/app/admin/blog/post-dialog";
import { Badge } from "@/components/ui/badge";
import { BlogActions } from "./blog-actions";

export default async function BlogAdminPage() {
  const [posts, categories] = await Promise.all([
    getBlogPosts(),
    getCategories('blogCategories')
  ]);

  const categoryNames = categories.map(c => c.name);

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
            <div>
                <CardTitle>Blog Posts</CardTitle>
                <CardDescription>Manage your {posts.length} blog posts.</CardDescription>
            </div>
            <PostDialog mode="add" categories={categoryNames} />
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="hidden w-[100px] sm:table-cell">
                <span className="sr-only">Image</span>
              </TableHead>
              <TableHead>Title</TableHead>
              <TableHead>Slug</TableHead>
              <TableHead className="hidden md:table-cell">Created At</TableHead>
              <TableHead>
                <span className="sr-only">Actions</span>
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {posts.map((post) => (
              <TableRow key={post.id}>
                <TableCell className="hidden sm:table-cell">
                  <Image
                    alt={post.title}
                    className="aspect-square rounded-md object-cover"
                    height="64"
                    src={post.coverImageUrl || 'https://placehold.co/100x100.png'}
                    width="64"
                  />
                </TableCell>
                <TableCell className="font-medium">{post.title}</TableCell>
                <TableCell>
                  <Badge variant="outline">/blog/{post.slug}</Badge>
                </TableCell>
                <TableCell className="hidden md:table-cell">
                  {post.createdAt ? new Date(post.createdAt).toLocaleDateString() : ''}
                </TableCell>
                <TableCell>
                  <BlogActions post={post} categories={categoryNames} />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
