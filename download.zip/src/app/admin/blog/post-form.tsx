
'use client';

import { useEffect, useTransition, useMemo, useCallback } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useFormState } from 'react-dom';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { upsertPostAction } from '@/app/admin/blog/actions';
import type { BlogPost } from '@/lib/types';
import { generateSlug } from '@/lib/utils';
import { debounce } from 'lodash';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const PostFormSchema = z.object({
  title: z.string().min(1, "Title is required."),
  slug: z.string().min(1, "Slug is required."),
  content: z.string().min(1, "Content is required."),
  coverImageUrl: z.string().url("A valid cover image URL is required."),
  category: z.string().min(1, "Category is required."),
  tags: z.string().optional(),
});

type FormValues = z.infer<typeof PostFormSchema>;

type PostFormProps = {
  mode: 'add' | 'edit';
  post?: BlogPost;
  onSuccess: () => void;
  categories: string[];
};

export function PostForm({ mode, post, onSuccess, categories }: PostFormProps) {
  const [state, formAction] = useFormState(upsertPostAction, {
    message: null,
    success: false,
  });
  const [isPending, startTransition] = useTransition();
  const { toast } = useToast();
  
  const defaultValues = useMemo(() => ({
      title: post?.title || '',
      slug: post?.slug || '',
      content: post?.content || '',
      coverImageUrl: post?.coverImageUrl || '',
      category: post?.category || '',
      tags: post?.tags?.join(', ') || '',
  }), [post]);

  const form = useForm<FormValues>({
    resolver: zodResolver(PostFormSchema),
    defaultValues: defaultValues,
  });

  const title = form.watch('title');

  useEffect(() => {
    if (mode === 'add') {
      const debouncedSlugUpdate = debounce(() => {
        if (!form.formState.isDirty) {
          form.setValue('slug', generateSlug(title));
        }
      }, 500);
      debouncedSlugUpdate();
      return () => debouncedSlugUpdate.cancel();
    }
  }, [title, form, mode]);


  useEffect(() => {
    if (state.message) {
      if (state.success) {
        toast({ title: 'Success!', description: state.message });
        onSuccess();
      } else {
        toast({ title: 'Error', description: state.message, variant: 'destructive' });
      }
    }
  }, [state, onSuccess, toast]);
  
  const handleSubmit = (data: FormValues) => {
    const formData = new FormData();
    // Loop through the validated data and append to formData
    Object.entries(data).forEach(([key, value]) => {
        if (value) {
            formData.append(key, value);
        }
    });

    if (mode === 'edit' && post?.id) {
        formData.append('postId', post.id);
    }
    
    startTransition(() => {
        formAction(formData);
    });
  }

  return (
    <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label htmlFor="title">Post Title</Label>
            <Input id="title" {...form.register('title')} />
            {form.formState.errors.title && <p className="text-sm text-destructive">{form.formState.errors.title.message}</p>}
          </div>

        <div className="space-y-2">
            <Label htmlFor="slug">Slug</Label>
            <Input id="slug" {...form.register('slug')} readOnly={mode === 'add'} />
            <p className="text-xs text-muted-foreground">URL-friendly version of the title. Auto-generated.</p>
            {form.formState.errors.slug && <p className="text-sm text-destructive">{form.formState.errors.slug.message}</p>}
        </div>
      </div>

       <div className="space-y-2">
        <Label htmlFor="coverImageUrl">Cover Image URL</Label>
        <Input id="coverImageUrl" {...form.register('coverImageUrl')} placeholder="https://example.com/image.png" />
        {form.formState.errors.coverImageUrl && <p className="text-sm text-destructive mt-1">{form.formState.errors.coverImageUrl.message}</p>}
      </div>

       <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="category">Category</Label>
          <Select onValueChange={(value) => form.setValue('category', value, { shouldValidate: true })} defaultValue={form.getValues('category')}>
            <SelectTrigger id="category">
              <SelectValue placeholder="Select a category" />
            </SelectTrigger>
            <SelectContent>
              {categories.map(cat => (
                <SelectItem key={cat} value={cat}>{cat}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          {form.formState.errors.category && <p className="text-sm text-destructive">{form.formState.errors.category.message}</p>}
        </div>
        <div className="space-y-2">
            <Label htmlFor="tags">Tags (comma-separated)</Label>
            <Input id="tags" {...form.register('tags')} placeholder="e.g. archviz, tutorial, blender"/>
        </div>
      </div>


      <div className="space-y-2">
        <Label htmlFor="content">Content (Markdown supported)</Label>
        <Textarea id="content" {...form.register('content')} rows={15} />
        {form.formState.errors.content && <p className="text-sm text-destructive">{form.formState.errors.content.message}</p>}
      </div>
      
      <div className="flex justify-end gap-2">
        <Button type="submit" disabled={isPending}>
          {isPending ? (mode === 'add' ? 'Creating...' : 'Saving...') : 'Save Post'}
        </Button>
      </div>
    </form>
  );
}
