
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import Image from "next/image";
import { getDownloadables, getCategories } from "@/lib/data";
import { DownloadableDialog } from "@/app/admin/downloads/downloadable-dialog";
import { DownloadableActions } from "@/app/admin/downloads/downloadable-actions";
import { Badge } from "@/components/ui/badge";

export default async function DownloadsAdminPage() {
  const [items, categories] = await Promise.all([
    getDownloadables(),
    getCategories('downloadCategories')
  ]);

  const categoryNames = categories.map(c => c.name);

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
            <div>
                <CardTitle>Downloadable Items</CardTitle>
                <CardDescription>Manage your {items.length} downloadable items.</CardDescription>
            </div>
            <DownloadableDialog mode="add" categories={categoryNames} />
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="hidden w-[100px] sm:table-cell">
                <span className="sr-only">Image</span>
              </TableHead>
              <TableHead>Title</TableHead>
              <TableHead>Category</TableHead>
              <TableHead>Versions</TableHead>
              <TableHead>
                <span className="sr-only">Actions</span>
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {items.map((item) => (
              <TableRow key={item.id}>
                <TableCell className="hidden sm:table-cell">
                  <Image
                    alt={item.title}
                    className="aspect-square rounded-md object-cover"
                    height="64"
                    src={item.imageUrl || 'https://placehold.co/100x100.png'}
                    width="64"
                  />
                </TableCell>
                <TableCell className="font-medium">{item.title}</TableCell>
                <TableCell>
                  <Badge variant="outline">{item.category}</Badge>
                </TableCell>
                 <TableCell>{item.versions.length}</TableCell>
                <TableCell>
                  <DownloadableActions item={item} categories={categoryNames} />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
