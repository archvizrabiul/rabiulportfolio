
'use server';

import { z } from 'zod';
import { revalidatePath } from 'next/cache';
import { db, firebaseInitialized } from '@/lib/firebase';
import { doc, addDoc, updateDoc, deleteDoc, collection, serverTimestamp } from 'firebase/firestore';

const DownloadableVersionSchema = z.object({
    name: z.string().min(1, 'Version name is required.'),
    url: z.string().url('A valid URL is required.'),
});

const DownloadableSchema = z.object({
  title: z.string().min(1, "Title is required."),
  category: z.string().min(1, "Category is required."),
  imageUrl: z.string().url("A valid image URL is required."),
  versions: z.array(DownloadableVersionSchema).min(1, "At least one version is required."),
});

type DownloadableState = {
  message?: string | null;
  success?: boolean;
  errors?: {
    [key: string]: any;
  };
};

export async function upsertDownloadableAction(
  prevState: DownloadableState,
  formData: FormData
): Promise<DownloadableState> {
  if (!firebaseInitialized || !db) {
    return {
      message: 'Database not configured. Cannot save item.',
      success: false,
    };
  }

  const downloadableId = formData.get('downloadableId') as string | null;

  const versions = formData.getAll('versions.name').map((name, i) => ({
    name: name as string,
    url: formData.get(`versions.url.${i}`) as string,
  })).filter(v => v.name && v.url); // Filter out empty entries from the form

  const rawData = {
    title: formData.get('title'),
    category: formData.get('category'),
    imageUrl: formData.get('imageUrl'),
    versions: versions
  }

  const validatedFields = DownloadableSchema.safeParse(rawData);

  if (!validatedFields.success) {
    return {
      message: 'Validation failed.',
      errors: validatedFields.error.flatten().fieldErrors,
      success: false,
    };
  }

  const data = validatedFields.data;

  try {
    if (downloadableId) {
      const itemRef = doc(db, 'downloadables', downloadableId);
      await updateDoc(itemRef, data);
    } else {
      await addDoc(collection(db, 'downloadables'), {
        ...data,
        createdAt: serverTimestamp(),
      });
    }

    revalidatePath('/admin/downloads');
    revalidatePath('/downloads');

    return {
      message: `Item successfully ${downloadableId ? 'updated' : 'created'}.`,
      success: true,
    };
  } catch (error) {
    console.error('Error upserting downloadable:', error);
    return {
      message: `An error occurred: ${error instanceof Error ? error.message : 'Unknown error'}.`,
      success: false,
    };
  }
}

export async function deleteDownloadableAction(itemId: string): Promise<{ success: boolean; message: string }> {
  if (!firebaseInitialized || !db) {
    return { success: false, message: 'Database not configured. Cannot delete item.' };
  }
  if (!itemId) {
    return { success: false, message: 'Item ID is required.' };
  }

  try {
    const itemRef = doc(db, 'downloadables', itemId);
    await deleteDoc(itemRef);

    revalidatePath('/admin/downloads');
    revalidatePath('/downloads');

    return { success: true, message: 'Item deleted successfully.' };
  } catch (error) {
    console.error('Error deleting item:', error);
    return {
      success: false,
      message: `Failed to delete item: ${error instanceof Error ? error.message : 'Unknown error'}`,
    };
  }
}
