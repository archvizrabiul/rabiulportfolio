
'use client';

import { useEffect, useTransition, useMemo } from 'react';
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useFormState } from 'react-dom';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import type { Downloadable } from '@/lib/types';
import { upsertDownloadableAction } from './actions';
import { PlusCircle, Trash2 } from 'lucide-react';

const DownloadableVersionSchema = z.object({
    name: z.string().min(1, 'Version name is required.'),
    url: z.string().url('A valid URL is required.'),
});

const DownloadableFormSchema = z.object({
  title: z.string().min(1, "Title is required."),
  category: z.string().min(1, "Category is required."),
  imageUrl: z.string().url("A valid image URL is required."),
  versions: z.array(DownloadableVersionSchema).min(1, "At least one version is required."),
});

type FormValues = z.infer<typeof DownloadableFormSchema>;

type DownloadableFormProps = {
  mode: 'add' | 'edit';
  item?: Downloadable;
  onSuccess: () => void;
  categories: string[];
};

export function DownloadableForm({ mode, item, onSuccess, categories }: DownloadableFormProps) {
  const [state, formAction] = useFormState(upsertDownloadableAction, { message: null, success: false });
  const [isPending, startTransition] = useTransition();
  const { toast } = useToast();

  const defaultValues = useMemo(() => ({
      title: item?.title || '',
      category: item?.category || '',
      imageUrl: item?.imageUrl || '',
      versions: item?.versions || [{ name: '', url: '' }],
  }), [item]);

  const form = useForm<FormValues>({
    resolver: zodResolver(DownloadableFormSchema),
    defaultValues,
  });
  
  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "versions"
  });

  useEffect(() => {
    if (state.message) {
      if (state.success) {
        toast({ title: 'Success!', description: state.message });
        onSuccess();
      } else {
        toast({ title: 'Error', description: state.message, variant: 'destructive' });
      }
    }
  }, [state, onSuccess, toast]);
  
  const handleSubmit = (data: FormValues) => {
    const formData = new FormData();
    formData.append('title', data.title);
    formData.append('category', data.category);
    formData.append('imageUrl', data.imageUrl);
    
    data.versions.forEach((version, index) => {
      formData.append(`versions.name`, version.name);
      formData.append(`versions.url.${index}`, version.url);
    });

    if (mode === 'edit' && item?.id) {
        formData.append('downloadableId', item.id);
    }
    
    startTransition(() => formAction(formData));
  }

  return (
    <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label htmlFor="title">Title</Label>
            <Input id="title" {...form.register('title')} />
            {form.formState.errors.title && <p className="text-sm text-destructive">{form.formState.errors.title.message}</p>}
          </div>

        <div className="space-y-2">
          <Label htmlFor="category">Category</Label>
          <Select onValueChange={(value) => form.setValue('category', value, { shouldValidate: true })} defaultValue={form.getValues('category')}>
            <SelectTrigger id="category">
              <SelectValue placeholder="Select a category" />
            </SelectTrigger>
            <SelectContent>
              {categories.map(cat => (
                <SelectItem key={cat} value={cat}>{cat}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          {form.formState.errors.category && <p className="text-sm text-destructive">{form.formState.errors.category.message}</p>}
        </div>
      </div>

       <div className="space-y-2">
        <Label htmlFor="imageUrl">Image URL</Label>
        <Input id="imageUrl" {...form.register('imageUrl')} placeholder="https://example.com/image.png" />
        {form.formState.errors.imageUrl && <p className="text-sm text-destructive mt-1">{form.formState.errors.imageUrl.message}</p>}
      </div>

      <div className="space-y-4">
        <Label>Versions</Label>
        <div className="space-y-4">
            {fields.map((field, index) => (
                <div key={field.id} className="flex items-end gap-2 p-3 border rounded-md bg-secondary/50">
                    <div className="grid grid-cols-1 gap-2 flex-grow">
                        <div className="space-y-1">
                            <Label htmlFor={`versions.${index}.name`} className="text-xs">Name</Label>
                            <Input {...form.register(`versions.${index}.name`)} placeholder="e.g. 2022, FBX" />
                        </div>
                        <div className="space-y-1">
                            <Label htmlFor={`versions.${index}.url`} className="text-xs">File URL</Label>
                            <Input {...form.register(`versions.${index}.url`)} placeholder="https://example.com/file.zip" />
                        </div>
                    </div>
                    <Button type="button" variant="destructive" size="icon" onClick={() => remove(index)}><Trash2 className="h-4 w-4"/></Button>
                </div>
            ))}
        </div>
         {form.formState.errors.versions && <p className="text-sm text-destructive">{form.formState.errors.versions.message || form.formState.errors.versions.root?.message}</p>}
        <Button type="button" variant="outline" size="sm" onClick={() => append({ name: '', url: '' })}><PlusCircle className="mr-2 h-4 w-4"/> Add Version</Button>
      </div>

      <div className="flex justify-end gap-2">
        <Button type="submit" disabled={isPending}>
          {isPending ? (mode === 'add' ? 'Creating...' : 'Saving...') : "Save Item"}
        </Button>
      </div>
    </form>
  );
}
