
'use client';

import { MoreHorizontal } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { DownloadableDialog } from "./downloadable-dialog";
import { DeleteDownloadableDialog } from './delete-downloadable-dialog';
import type { Downloadable } from '@/lib/types';

type DownloadableActionsProps = {
    item: Downloadable;
    categories: string[];
};

export function DownloadableActions({ item, categories }: DownloadableActionsProps) {
    return (
        <DropdownMenu>
            <DropdownMenuTrigger aria-haspopup="true">
                <MoreHorizontal className="h-4 w-4" />
                <span className="sr-only">Toggle menu</span>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                <DownloadableDialog mode="edit" item={item} categories={categories}>
                    <DropdownMenuItem onSelect={(e) => e.preventDefault()}>Edit</DropdownMenuItem>
                </DownloadableDialog>
                <DeleteDownloadableDialog itemId={item.id} itemTitle={item.title}>
                    <DropdownMenuItem onSelect={(e) => e.preventDefault()} className="text-destructive focus:text-destructive focus:bg-destructive/10">
                        Delete
                    </DropdownMenuItem>
                </DeleteDownloadableDialog>
            </DropdownMenuContent>
        </DropdownMenu>
    );
}
