
'use client';

import { useState, useCallback } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { PlusCircle } from 'lucide-react';
import type { Downloadable } from '@/lib/types';
import { DownloadableForm } from '@/app/admin/downloads/downloadable-form';

type DownloadableDialogProps = {
  mode: 'add' | 'edit';
  item?: Downloadable;
  categories: string[];
  children?: React.ReactNode;
};

export function DownloadableDialog({ mode, item, categories, children }: DownloadableDialogProps) {
  const [open, setOpen] = useState(false);

  const handleSuccess = useCallback(() => {
    setOpen(false);
  }, []);

  const triggerButton =
    mode === 'add' ? (
      <Button>
        <PlusCircle className="mr-2 h-4 w-4" /> Add Item
      </Button>
    ) : (
      <div className="w-full">{children}</div>
    );

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{triggerButton}</DialogTrigger>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{mode === 'add' ? 'Add New Item' : 'Edit Item'}</DialogTitle>
          <DialogDescription>
            Fill out the details below to {mode} your downloadable item. Click save when you're done.
          </DialogDescription>
        </DialogHeader>
        <DownloadableForm
          mode={mode}
          item={item}
          onSuccess={handleSuccess}
          categories={categories}
        />
      </DialogContent>
    </Dialog>
  );
}
