
'use server';

import { Sidebar, SidebarContent, SidebarFooter, SidebarHeader, SidebarMenu, SidebarMenuItem, SidebarMenuButton, SidebarProvider, SidebarTrigger, SidebarGroup, SidebarGroupLabel, SidebarGroupContent } from '@/components/ui/sidebar';
import { LayoutDashboard, Mail, UserCircle, FileText, BookText, Settings, DownloadCloud, LogOut } from 'lucide-react';
import Link from 'next/link';
import { cn } from '@/lib/utils';
import { getSession, deleteSession } from '@/lib/session';
import { redirect } from 'next/navigation';

export default async function AdminLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    const session = await getSession();
    if (!session?.userId) {
        redirect('/admin/login');
    }

    return (
        <SidebarProvider>
            <div className="flex min-h-screen">
                <Sidebar>
                    <SidebarContent>
                        <SidebarHeader className="justify-between">
                            <h2 className="text-xl font-headline group-data-[collapsible=icon]:hidden">Dashboard</h2>
                            <SidebarTrigger />
                        </SidebarHeader>
                        <SidebarMenu>
                             <SidebarGroup>
                                <SidebarGroupLabel>Content</SidebarGroupLabel>
                                <SidebarGroupContent>
                                    <SidebarMenuItem>
                                        <SidebarMenuButton asChild>
                                            <Link href="/admin/dashboard">
                                                <LayoutDashboard />
                                                <span>Projects</span>
                                            </Link>
                                        </SidebarMenuButton>
                                    </SidebarMenuItem>
                                    <SidebarMenuItem>
                                        <SidebarMenuButton asChild>
                                            <Link href="/admin/blog">
                                                <BookText />
                                                <span>Blog</span>
                                            </Link>
                                        </SidebarMenuButton>
                                    </SidebarMenuItem>
                                     <SidebarMenuItem>
                                        <SidebarMenuButton asChild>
                                            <Link href="/admin/downloads">
                                                <DownloadCloud />
                                                <span>Downloads</span>
                                            </Link>
                                        </SidebarMenuButton>
                                    </SidebarMenuItem>
                                 </SidebarGroupContent>
                             </SidebarGroup>
                             <SidebarGroup>
                                <SidebarGroupLabel>Profile</SidebarGroupLabel>
                                <SidebarGroupContent>
                                    <SidebarMenuItem>
                                        <SidebarMenuButton asChild>
                                            <Link href="/admin/profile">
                                                <UserCircle />
                                                <span>Profile</span>
                                            </Link>
                                        </SidebarMenuButton>
                                    </SidebarMenuItem>
                                    <SidebarMenuItem>
                                        <SidebarMenuButton asChild>
                                            <Link href="/admin/cv">
                                                <FileText />
                                                <span>CV Content</span>
                                            </Link>
                                        </SidebarMenuButton>
                                    </SidebarMenuItem>
                                </SidebarGroupContent>
                             </SidebarGroup>
                             <SidebarGroup>
                                <SidebarGroupLabel>Inbox</SidebarGroupLabel>
                                <SidebarGroupContent>
                                    <SidebarMenuItem>
                                        <SidebarMenuButton asChild>
                                            <Link href="/admin/messages">
                                                <Mail />
                                                <span>Messages</span>
                                            </Link>
                                        </SidebarMenuButton>
                                    </SidebarMenuItem>
                                </SidebarGroupContent>
                             </SidebarGroup>
                             <SidebarGroup>
                                <SidebarGroupLabel>Configuration</SidebarGroupLabel>
                                <SidebarGroupContent>
                                    <SidebarMenuItem>
                                        <SidebarMenuButton asChild>
                                            <Link href="/admin/settings">
                                                <Settings />
                                                <span>Settings</span>
                                            </Link>
                                        </SidebarMenuButton>
                                    </SidebarMenuItem>
                                </SidebarGroupContent>
                             </SidebarGroup>
                        </SidebarMenu>
                    </SidebarContent>
                     <SidebarFooter>
                        <form action={async () => {
                            'use server';
                            await deleteSession();
                            redirect('/admin/login');
                        }}>
                             <SidebarMenu>
                                <SidebarMenuItem>
                                    <SidebarMenuButton type="submit">
                                        <LogOut />
                                        <span>Logout</span>
                                    </SidebarMenuButton>
                                </SidebarMenuItem>
                             </SidebarMenu>
                        </form>
                    </SidebarFooter>
                </Sidebar>
                <main className="flex-1 p-4 md:p-8 overflow-auto bg-muted/40 peer-data-[collapsible=icon]:[--sidebar-width:var(--sidebar-width-icon)]">
                    <div className="pb-4">
                        <SidebarTrigger />
                    </div>
                    <div className="animate-fade-in">
                        {children}
                    </div>
                </main>
            </div>
        </SidebarProvider>
    );
}
