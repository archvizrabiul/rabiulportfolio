import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { getProfile } from "@/lib/data";
import { CvForm } from "@/app/admin/cv/cv-form";

export default async function CvContentPage() {
  const profile = await getProfile();

  return (
    <Card>
      <CardHeader>
        <CardTitle>Manage CV Content</CardTitle>
        <CardDescription>Update the Education, Certification, and Work Experience sections of your public profile and CV.</CardDescription>
      </CardHeader>
      <CardContent>
        <CvForm profile={profile} />
      </CardContent>
    </Card>
  );
}
