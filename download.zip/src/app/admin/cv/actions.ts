'use server';

import { z } from 'zod';
import { revalidatePath } from 'next/cache';
import { db, firebaseInitialized } from '@/lib/firebase';
import { doc, setDoc } from 'firebase/firestore';

const EducationItemSchema = z.object({
  institution: z.string().min(1, "Institution is required."),
  degree: z.string().min(1, "Degree is required."),
  period: z.string().min(1, "Period is required."),
  focus: z.string().min(1, "Focus is required."),
});

const CertificationItemSchema = z.object({
  program: z.string().min(1, "Program is required."),
  field: z.string().min(1, "Field is required."),
  period: z.string().min(1, "Period is required."),
  skills: z.string().min(1, "Skills are required."),
});

const WorkExperienceItemSchema = z.object({
  role: z.string().min(1, "Role is required."),
  company: z.string().min(1, "Company is required."),
  period: z.string().min(1, "Period is required."),
  description: z.string().min(1, "Description is required."),
});

const CvSchema = z.object({
  education: z.array(EducationItemSchema),
  certifications: z.array(CertificationItemSchema),
  experience: z.array(WorkExperienceItemSchema),
});

type CvState = {
  message?: string | null;
  success?: boolean;
  errors?: {
    [key: string]: any;
  };
};

export async function updateCvAction(
  prevState: CvState,
  formData: FormData
): Promise<CvState> {
  if (!firebaseInitialized || !db) {
    return {
      message: 'Database not configured. Cannot save CV content.',
      success: false,
    };
  }

  const rawData = Object.fromEntries(formData.entries());

  const education = formData.getAll('education').map((_, i) => ({
    institution: formData.get(`education[${i}].institution`) as string,
    degree: formData.get(`education[${i}].degree`) as string,
    period: formData.get(`education[${i}].period`) as string,
    focus: formData.get(`education[${i}].focus`) as string,
  }));

  const certifications = formData.getAll('certifications').map((_, i) => ({
    program: formData.get(`certifications[${i}].program`) as string,
    field: formData.get(`certifications[${i}].field`) as string,
    period: formData.get(`certifications[${i}].period`) as string,
    skills: formData.get(`certifications[${i}].skills`) as string,
  }));

  const experience = formData.getAll('experience').map((_, i) => ({
    role: formData.get(`experience[${i}].role`) as string,
    company: formData.get(`experience[${i}].company`) as string,
    period: formData.get(`experience[${i}].period`) as string,
    description: formData.get(`experience[${i}].description`) as string,
  }));
  
  const validatedFields = CvSchema.safeParse({
    education,
    certifications,
    experience
  });

  if (!validatedFields.success) {
    return {
      message: 'Validation failed.',
      errors: validatedFields.error.flatten().fieldErrors,
      success: false,
    };
  }

  try {
    const profileRef = doc(db, 'profile', 'main');
    await setDoc(profileRef, validatedFields.data, { merge: true });

    revalidatePath('/admin/cv');
    revalidatePath('/cv');
    revalidatePath('/');

    return {
      message: 'CV content updated successfully.',
      success: true,
    };
  } catch (error) {
    console.error('Error updating CV content:', error);
    return {
      message: 'An error occurred while updating the CV content.',
      success: false,
    };
  }
}
