
'use client';

import { useEffect, useTransition } from 'react';
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useFormState } from 'react-dom';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { PlusCircle, Trash2 } from 'lucide-react';
import type { Profile } from '@/lib/types';
import { updateCvAction } from '@/app/admin/cv/actions';

const EducationItemSchema = z.object({
  institution: z.string().min(1, "required"),
  degree: z.string().min(1, "required"),
  period: z.string().min(1, "required"),
  focus: z.string().min(1, "required"),
});

const CertificationItemSchema = z.object({
  program: z.string().min(1, "required"),
  field: z.string().min(1, "required"),
  period: z.string().min(1, "required"),
  skills: z.string().min(1, "required"),
});

const WorkExperienceItemSchema = z.object({
  role: z.string().min(1, "required"),
  company: z.string().min(1, "required"),
  period: z.string().min(1, "required"),
  description: z.string().min(1, "required"),
});

const CvFormSchema = z.object({
  education: z.array(EducationItemSchema),
  certifications: z.array(CertificationItemSchema),
  experience: z.array(WorkExperienceItemSchema),
});

type CvFormValues = z.infer<typeof CvFormSchema>;

type CvFormProps = {
  profile: Profile;
};

const SectionCard = ({ title, children }: { title: string, children: React.ReactNode }) => (
    <Card className="bg-secondary/50">
        <CardHeader><CardTitle>{title}</CardTitle></CardHeader>
        <CardContent>{children}</CardContent>
    </Card>
);

export function CvForm({ profile }: CvFormProps) {
    const [state, formAction] = useFormState(updateCvAction, { message: null, success: false });
    const [isPending, startTransition] = useTransition();
    const { toast } = useToast();

    const form = useForm<CvFormValues>({
        resolver: zodResolver(CvFormSchema),
        defaultValues: {
            education: profile?.education || [],
            certifications: profile?.certifications || [],
            experience: profile?.experience || [],
        },
    });
    
    const { control } = form;

    const { fields: eduFields, append: appendEdu, remove: removeEdu } = useFieldArray({ control, name: 'education' });
    const { fields: certFields, append: appendCert, remove: removeCert } = useFieldArray({ control, name: 'certifications' });
    const { fields: expFields, append: appendExp, remove: removeExp } = useFieldArray({ control, name: 'experience' });

    useEffect(() => {
        if (state.message) {
            toast({
                title: state.success ? 'Success!' : 'Error',
                description: state.message,
                variant: state.success ? 'default' : 'destructive',
            });
        }
    }, [state]);

    const handleSubmit = (data: CvFormValues) => {
        const formData = new FormData();
        
        data.education.forEach((item, index) => {
            formData.append('education', 'item');
            Object.entries(item).forEach(([key, value]) => {
                formData.append(`education[${index}].${key}`, value);
            });
        });
        data.certifications.forEach((item, index) => {
            formData.append('certifications', 'item');
            Object.entries(item).forEach(([key, value]) => {
                formData.append(`certifications[${index}].${key}`, value);
            });
        });
        data.experience.forEach((item, index) => {
            formData.append('experience', 'item');
            Object.entries(item).forEach(([key, value]) => {
                formData.append(`experience[${index}].${key}`, value);
            });
        });

        startTransition(() => formAction(formData));
    };

    return (
        <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-8">
            <SectionCard title="Education">
                <div className="space-y-4">
                    {eduFields.map((field, index) => (
                        <div key={field.id} className="p-4 border rounded-lg space-y-2 relative bg-background">
                            <Input {...form.register(`education.${index}.institution`)} placeholder="Institution" />
                            <Input {...form.register(`education.${index}.degree`)} placeholder="Degree/Course" />
                            <Input {...form.register(`education.${index}.period`)} placeholder="Period (e.g., 2018-2022)" />
                            <Input {...form.register(`education.${index}.focus`)} placeholder="Focus/Details" />
                            <Button type="button" variant="destructive" size="icon" onClick={() => removeEdu(index)} className="absolute top-2 right-2 h-7 w-7"><Trash2 className="w-4 h-4"/></Button>
                        </div>
                    ))}
                </div>
                <Button type="button" variant="outline" size="sm" onClick={() => appendEdu({ institution: '', degree: '', period: '', focus: '' })} className="mt-4"><PlusCircle className="mr-2 h-4 w-4" /> Add Education</Button>
            </SectionCard>

            <SectionCard title="Certifications">
                 <div className="space-y-4">
                    {certFields.map((field, index) => (
                        <div key={field.id} className="p-4 border rounded-lg space-y-2 relative bg-background">
                            <Input {...form.register(`certifications.${index}.program`)} placeholder="Program (e.g., ISDB-BISEW)" />
                            <Input {...form.register(`certifications.${index}.field`)} placeholder="Field (e.g., Architectural with Civil CAD)" />
                            <Input {...form.register(`certifications.${index}.period`)} placeholder="Period (e.g., Oct 2024 - Aug 2025)" />
                            <Input {...form.register(`certifications.${index}.skills`)} placeholder="Skills Learned" />
                            <Button type="button" variant="destructive" size="icon" onClick={() => removeCert(index)} className="absolute top-2 right-2 h-7 w-7"><Trash2 className="w-4 h-4"/></Button>
                        </div>
                    ))}
                </div>
                <Button type="button" variant="outline" size="sm" onClick={() => appendCert({ program: '', field: '', period: '', skills: '' })} className="mt-4"><PlusCircle className="mr-2 h-4 w-4" /> Add Certification</Button>
            </SectionCard>

            <SectionCard title="Work Experience">
                 <div className="space-y-4">
                    {expFields.map((field, index) => (
                        <div key={field.id} className="p-4 border rounded-lg space-y-2 relative bg-background">
                            <Input {...form.register(`experience.${index}.role`)} placeholder="Role (e.g., Junior Instructor)" />
                            <Input {...form.register(`experience.${index}.company`)} placeholder="Company (e.g., NIST)" />
                            <Input {...form.register(`experience.${index}.period`)} placeholder="Period (e.g., June 2024 - Sep 2024)" />
                            <Textarea {...form.register(`experience.${index}.description`)} placeholder="Description" />
                            <Button type="button" variant="destructive" size="icon" onClick={() => removeExp(index)} className="absolute top-2 right-2 h-7 w-7"><Trash2 className="w-4 h-4"/></Button>
                        </div>
                    ))}
                </div>
                <Button type="button" variant="outline" size="sm" onClick={() => appendExp({ role: '', company: '', period: '', description: '' })} className="mt-4"><PlusCircle className="mr-2 h-4 w-4" /> Add Experience</Button>
            </SectionCard>

            <div className="flex justify-end">
                <Button type="submit" disabled={isPending}>{isPending ? 'Saving...' : 'Save CV Content'}</Button>
            </div>
        </form>
    );
}
