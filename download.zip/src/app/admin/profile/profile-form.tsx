
'use client';

import { useEffect, useTransition, useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useFormState } from 'react-dom';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { updateProfileAction } from './actions';
import type { Profile } from '@/lib/types';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const ProfileSchema = z.object({
  name: z.string().min(1, "Name is required."),
  title: z.string().min(1, "Title is required."),
  bio: z.string().min(1, "Bio is required."),
  profilePictureUrl: z.string().url("A valid profile picture URL is required."),
  cvUrl: z.string().url("A valid CV URL is required."),
  siteTheme: z.enum(['light', 'dark', 'system']).default('system'),
});

type ProfileFormValues = z.infer<typeof ProfileSchema>;

type ProfileFormProps = {
  profile: Profile;
};

export function ProfileForm({ profile }: ProfileFormProps) {
  const [state, formAction] = useFormState(updateProfileAction, {
    message: null,
    success: false,
  });
  const [isPending, startTransition] = useTransition();
  const { toast } = useToast();

  const defaultValues = useMemo(() => ({
    name: profile?.name || '',
    title: profile?.title || '',
    bio: profile?.bio || '',
    profilePictureUrl: profile?.profilePictureUrl || '',
    cvUrl: profile?.cvUrl || '',
    siteTheme: profile?.siteTheme || 'system',
  }), [profile]);

  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(ProfileSchema),
    defaultValues,
  });

  useEffect(() => {
    form.reset(defaultValues);
  }, [defaultValues, form]);
  
  useEffect(() => {
    if (state.message) {
      if (state.success) {
        toast({ title: 'Success!', description: state.message });
      } else {
        toast({ title: 'Error', description: state.message, variant: 'destructive' });
      }
    }
  }, [state, toast]);

  const handleSubmit = (data: ProfileFormValues) => {
    const formData = new FormData();
    Object.entries(data).forEach(([key, value]) => {
        if(value) {
            formData.append(key, value);
        }
    });
    startTransition(() => {
      formAction(formData);
    });
  };

  return (
    <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="name">Full Name</Label>
          <Input id="name" {...form.register('name')} />
          {form.formState.errors.name && <p className="text-sm text-destructive">{form.formState.errors.name.message}</p>}
        </div>
        <div className="space-y-2">
          <Label htmlFor="title">Title / Tagline</Label>
          <Input id="title" {...form.register('title')} />
          {form.formState.errors.title && <p className="text-sm text-destructive">{form.formState.errors.title.message}</p>}
        </div>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="bio">Biography</Label>
        <Textarea id="bio" {...form.register('bio')} rows={5} />
        {form.formState.errors.bio && <p className="text-sm text-destructive">{form.formState.errors.bio.message}</p>}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="profilePictureUrl">Profile Picture URL</Label>
          <Input id="profilePictureUrl" {...form.register('profilePictureUrl')} placeholder="https://example.com/profile.png" />
          {form.formState.errors.profilePictureUrl && <p className="text-sm text-destructive mt-1">{form.formState.errors.profilePictureUrl.message}</p>}
        </div>
        <div className="space-y-2">
          <Label htmlFor="cvUrl">CV Document URL</Label>
           <Input id="cvUrl" {...form.register('cvUrl')} placeholder="https://example.com/cv.pdf" />
          {form.formState.errors.cvUrl && <p className="text-sm text-destructive mt-1">{form.formState.errors.cvUrl.message}</p>}
        </div>
      </div>
      
      <div className="space-y-2">
          <Label htmlFor="siteTheme">Default Public Site Theme</Label>
            <Select onValueChange={(value) => form.setValue('siteTheme', value as 'light' | 'dark' | 'system', { shouldValidate: true })} defaultValue={form.getValues('siteTheme')}>
                <SelectTrigger id="siteTheme">
                    <SelectValue placeholder="Select a theme" />
                </SelectTrigger>
                <SelectContent>
                    <SelectItem value="light">Light</SelectItem>
                    <SelectItem value="dark">Dark</SelectItem>
                    <SelectItem value="system">System Default</SelectItem>
                </SelectContent>
            </Select>
           <p className="text-xs text-muted-foreground">Set the default color theme for all public visitors. This change is saved when you click "Save Profile".</p>
          {form.formState.errors.siteTheme && <p className="text-sm text-destructive">{form.formState.errors.siteTheme.message}</p>}
      </div>

      <div className="flex justify-end">
        <Button type="submit" disabled={isPending}>
          {isPending ? 'Saving...' : 'Save Profile'}
        </Button>
      </div>
    </form>
  );
}
