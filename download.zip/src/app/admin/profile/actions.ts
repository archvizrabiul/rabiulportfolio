'use server';

import { z } from 'zod';
import { revalidatePath } from 'next/cache';
import { db, firebaseInitialized } from '@/lib/firebase';
import { doc, setDoc } from 'firebase/firestore';

const ProfileSchema = z.object({
  name: z.string().min(1, "Name is required."),
  title: z.string().min(1, "Title is required."),
  bio: z.string().min(1, "Bio is required."),
  profilePictureUrl: z.string().url("A valid profile picture URL is required."),
  cvUrl: z.string().url("A valid CV URL is required."),
  siteTheme: z.enum(['light', 'dark', 'system']).optional(),
});

type ProfileState = {
  message?: string | null;
  success?: boolean;
  errors?: {
    [key: string]: string[] | undefined;
  };
};

export async function updateProfileAction(
  prevState: ProfileState,
  formData: FormData
): Promise<ProfileState> {
  if (!firebaseInitialized || !db) {
    return {
      message: 'Database not configured. Cannot update profile.',
      success: false,
    };
  }

  const validatedFields = ProfileSchema.safeParse(
    Object.fromEntries(formData.entries())
  );

  if (!validatedFields.success) {
    return {
      message: 'Validation failed.',
      errors: validatedFields.error.flatten().fieldErrors,
      success: false,
    };
  }

  try {
    const profileRef = doc(db, 'profile', 'main');
    await setDoc(profileRef, validatedFields.data, { merge: true });

    // Revalidate all pages that use profile data
    revalidatePath('/admin/profile');
    revalidatePath('/');
    revalidatePath('/cv');
    revalidatePath('/blog');
    revalidatePath('/portfolio');


    return {
      message: 'Profile updated successfully.',
      success: true,
    };
  } catch (error) {
    console.error('Error updating profile:', error);
    return {
      message: 'An error occurred while updating the profile.',
      success: false,
    };
  }
}
