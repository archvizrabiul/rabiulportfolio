
import { Header } from '@/components/header';
import { Footer } from '@/components/footer';
import { getDownloadables, getProfile, getCategories } from '@/lib/data';
import { DownloadDirectory } from '@/components/download-directory';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { Home, User } from 'lucide-react';
import { getSession } from '@/lib/session';

export default async function DownloadsPage() {
  const [items, profile, categories, session] = await Promise.all([
    getDownloadables(),
    getProfile(),
    getCategories('downloadCategories'),
    getSession()
  ]);
  
  const filters = ['All', ...categories.map(c => c.name)];

  return (
    <div className="flex flex-col min-h-dvh bg-secondary/20">
      <Header isSubPage={true} profile={profile} />
      <main className="flex-1 py-12 md:py-24 lg:py-32">
        <div className="container mx-auto px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
                <div className="space-y-2">
                    <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl font-headline text-primary">Download Directory</h1>
                    <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                        Explore and download from my collection of 3D models, scenes, and other resources.
                    </p>
                </div>
                 <div className="flex gap-2">
                    <Button asChild variant="outline">
                        <Link href="/">
                            <Home className="mr-2 h-4 w-4" />
                            Back to Homepage
                        </Link>
                    </Button>
                    {!session?.userId && (
                        <Button asChild>
                            <Link href="/admin/login">
                                <User className="mr-2 h-4 w-4" />
                                Login to Download
                            </Link>
                        </Button>
                    )}
                 </div>
            </div>

            <DownloadDirectory initialItems={items} filters={filters} />
        </div>
      </main>
      <Footer />
    </div>
  );
}
