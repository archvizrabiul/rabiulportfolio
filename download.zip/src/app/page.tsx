
import { Header } from '@/components/header';
import { HeroSection } from '@/components/sections/hero';
import { AboutSection } from '@/components/sections/about';
import { PortfolioSection } from '@/components/sections/portfolio';
import { BlogSection } from '@/components/sections/blog';
import { SkillsSection } from '@/components/sections/skills';
import { ContactSection } from '@/components/sections/contact';
import { getHomepageProjects, getProfile, getCategories, getBlogPosts, getProjects } from '@/lib/data';
import { Footer } from '@/components/footer';

export default async function Home() {
  const [profile, homepageProjects, projectCategories, blogPosts] = await Promise.all([
    getProfile(),
    getHomepageProjects(6),
    getCategories('projectCategories'),
    getBlogPosts()
  ]);
  
  const projectFilters = ['All', ...projectCategories.map(c => c.name)];
  const latestBlogPosts = blogPosts.slice(0, 3);
  
  // We need to know the total project count to decide if we show the "View All" button.
  // This is a more efficient way than fetching all project data.
  const allProjects = await getProjects();
  const totalProjectsCount = allProjects.length;


  return (
    <div className="flex flex-col min-h-dvh">
      <Header profile={profile} />
      <main className="flex-1">
        <HeroSection profile={profile} />
        <AboutSection profile={profile} />
        <PortfolioSection 
          initialProjects={homepageProjects} 
          filters={projectFilters} 
          totalProjectsCount={totalProjectsCount}
          isHomePage={true} 
        />
        <BlogSection posts={latestBlogPosts} />
        <SkillsSection />
        <ContactSection />
      </main>
      <Footer />
    </div>
  );
}
