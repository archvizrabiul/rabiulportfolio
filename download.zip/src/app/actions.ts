'use server';

import { enhanceProjectDescription as enhanceProjectDescriptionFlow } from '@/ai/flows/enhance-project-description';
import { z } from 'zod';
import { Resend } from 'resend';
import { db, firebaseInitialized } from '@/lib/firebase';
import { addDoc, collection, serverTimestamp } from 'firebase/firestore';

const EnhanceDescriptionSchema = z.object({
  description: z.string().min(10, "Please provide a more detailed description (min 10 characters)."),
});

type EnhanceState = {
    message?: string | null;
    errors?: {
        description?: string[] | undefined;
    }
    enhancedDescription?: string | null;
}

export async function enhanceDescriptionAction(prevState: EnhanceState, formData: FormData): Promise<EnhanceState> {
  const validatedFields = EnhanceDescriptionSchema.safeParse({
    description: formData.get('description'),
  });

  if (!validatedFields.success) {
    return {
      message: 'Validation failed.',
      errors: validatedFields.error.flatten().fieldErrors,
    };
  }

  try {
    const result = await enhanceProjectDescriptionFlow({
      projectDescription: validatedFields.data.description,
    });
    return {
      message: 'Success',
      enhancedDescription: result.enhancedDescription,
    };
  } catch (error) {
    console.error(error);
    return {
      message: 'An error occurred while enhancing the description.',
      enhancedDescription: null,
    };
  }
}


const ContactFormSchema = z.object({
    name: z.string().min(1, "Name is required."),
    email: z.string().email("Invalid email address."),
    message: z.string().min(10, "Message must be at least 10 characters."),
});

type ContactState = {
    message: string | null;
    success: boolean;
    errors?: {
        name?: string[];
        email?: string[];
        message?: string[];
    } | null;
};

export async function submitContactFormAction(prevState: ContactState, formData: FormData): Promise<ContactState> {
    const validatedFields = ContactFormSchema.safeParse({
        name: formData.get('name'),
        email: formData.get('email'),
        message: formData.get('message'),
    });

    if (!validatedFields.success) {
        return {
            message: "Validation failed. Please check your inputs.",
            errors: validatedFields.error.flatten().fieldErrors,
            success: false,
        };
    }
    
    const { name, email, message } = validatedFields.data;

    if(firebaseInitialized && db) {
        try {
            // Save to Firestore
            await addDoc(collection(db, 'contactMessages'), {
                name,
                email,
                message,
                createdAt: serverTimestamp(),
            });
        } catch (error) {
             console.error('Error saving to Firestore:', error);
             return {
                message: "Sorry, something went wrong and we couldn't save your message.",
                errors: null,
                success: false,
            };
        }
    } else {
        console.log("Firebase not initialized. Skipping Firestore save.");
    }


    // Optionally send email with Resend
    if (process.env.RESEND_API_KEY && process.env.ADMIN_EMAIL) {
        try {
            const resend = new Resend(process.env.RESEND_API_KEY);
            await resend.emails.send({
                from: 'Portfolio Contact Form <onboarding@resend.dev>',
                to: process.env.ADMIN_EMAIL,
                subject: 'New Message from your Portfolio',
                reply_to: email,
                html: `
                    <div>
                        <h2>New Contact Form Submission</h2>
                        <p><strong>Name:</strong> ${name}</p>
                        <p><strong>Email:</strong> ${email}</p>
                        <p><strong>Message:</strong></p>
                        <p>${message.replace(/\n/g, '<br>')}</p>
                    </div>
                `,
            });
        } catch (error) {
            console.error('Resend error:', error);
            // Don't block success if only email fails
        }
    }

    return {
        message: "Your message has been sent successfully!",
        errors: null,
        success: true,
    };
}
