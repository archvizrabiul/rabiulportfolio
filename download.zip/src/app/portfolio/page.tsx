
import { Header } from '@/components/header';
import { PortfolioSection } from '@/components/sections/portfolio';
import { Footer } from '@/components/footer';
import { getProjects, getProfile, getCategories } from '@/lib/data';

export default async function PortfolioPage() {
  const [allProjects, profile, projectCategories] = await Promise.all([
    getProjects(),
    getProfile(),
    getCategories('projectCategories')
  ]);
  
  const projectFilters = ['All', ...projectCategories.map(c => c.name)];

  return (
    <div className="flex flex-col min-h-dvh">
      <Header isSubPage={true} profile={profile} />
      <main className="flex-1">
        <PortfolioSection 
          initialProjects={allProjects} 
          filters={projectFilters}
        />
      </main>
      <Footer />
    </div>
  );
}
