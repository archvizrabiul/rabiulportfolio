
'use server';

import { z } from 'zod';
import { auth, firebaseInitialized, db } from '@/lib/firebase';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword } from 'firebase/auth';
import { createSession } from '@/lib/session';
import { redirect } from 'next/navigation';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import {Auth as AdminAuth, getAuth as getAdminAuth} from "firebase-admin/auth";
import { initializeAdmin } from '@/lib/firebase-admin';

// --- REGISTRATION ---

const RegisterSchema = z.object({
  email: z.string().email('Invalid email address.'),
  password: z.string().min(6, 'Password must be at least 6 characters.'),
});

type RegisterState = {
  message: string | null;
  success: boolean;
};

export async function registerAction(
  prevState: RegisterState,
  formData: FormData
): Promise<RegisterState> {
  if (!firebaseInitialized || !auth || !db) {
    return {
      message: 'Authentication service is not configured. Please try again later.',
      success: false,
    };
  }

  const validatedFields = RegisterSchema.safeParse(
    Object.fromEntries(formData.entries())
  );

  if (!validatedFields.success) {
    const firstError = validatedFields.error.errors[0];
    return {
      message: firstError.message,
      success: false,
    };
  }

  const { email, password } = validatedFields.data;

  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;

    // Create a corresponding user document in Firestore
    if (db) {
      await setDoc(doc(db, 'users', user.uid), {
          email: user.email,
          name: user.displayName || email.split('@')[0],
          provider: 'password',
          role: 'user', // default role
          createdAt: new Date().toISOString(),
      });
    }

    // Create session after successful registration
    await createSession(user.uid);
    
  } catch (error: any) {
    let message = 'An unknown error occurred.';
    if (error.code === 'auth/email-already-in-use') {
      message = 'This email address is already in use.';
    } else if (error.code === 'auth/weak-password') {
      message = 'The password is too weak.';
    }
    console.error('Registration error:', error);
    return {
      message,
      success: false,
    };
  }

  redirect('/admin/dashboard');
}

// --- LOGIN ---

const LoginSchema = z.object({
  email: z.string().email('Invalid email address.'),
  password: z.string().min(1, 'Password is required.'),
});

type LoginState = {
  message: string | null;
  success: boolean;
};

export async function loginAction(
  prevState: LoginState,
  formData: FormData
): Promise<LoginState> {
  if (!firebaseInitialized || !auth) {
    return {
      message: 'Authentication service is not configured.',
      success: false,
    };
  }
  
  const validatedFields = LoginSchema.safeParse(
    Object.fromEntries(formData.entries())
  );
  
  if (!validatedFields.success) {
      const firstError = validatedFields.error.errors[0];
      return {
          message: firstError.message,
          success: false,
      };
  }

  const { email, password } = validatedFields.data;

  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    await createSession(userCredential.user.uid);
  } catch (error: any) {
    let message = 'Login failed. Please check your credentials.';
    if (error.code === 'auth/user-not-found' || error.code === 'auth/wrong-password') {
        message = 'Invalid email or password.';
    } else if (error.code === 'auth/invalid-credential') {
        message = 'Invalid email or password. If you just registered, please wait a moment and try again.';
    }
    console.error('Login error:', error.code, error.message);
    return {
      message: message,
      success: false,
    };
  }

  redirect('/admin/dashboard');
}


// --- GOOGLE LOGIN ---
export async function createGoogleSessionAction(idToken: string) {
    if (!idToken) {
        return { error: 'ID token is missing.' };
    }
    
    try {
        await initializeAdmin();
        const adminAuth: AdminAuth = getAdminAuth();
        const decodedToken = await adminAuth.verifyIdToken(idToken);
        const uid = decodedToken.uid;
        const user = await adminAuth.getUser(uid);

        // Check if user exists in Firestore, if not, create them
        if (db) {
            const userDocRef = doc(db, 'users', uid);
            const userDoc = await getDoc(userDocRef);

            if (!userDoc.exists()) {
                await setDoc(userDocRef, {
                    email: user.email,
                    name: user.displayName,
                    provider: 'google',
                    role: 'user', // default role
                    createdAt: new Date().toISOString(),
                });
            }
        }
        
        await createSession(uid);

    } catch (error: any) {
        console.error("Google Session Creation error:", error);
        return { error: 'Failed to create session with Google. Please try again.' };
    }
    
    redirect('/admin/dashboard');
}
