import { Mail, Phone, MapPin } from 'lucide-react';
import Image from 'next/image';
import { getProfile } from '@/lib/data';

export default async function CVPage() {
  const profile = await getProfile();

  return (
    <div className="bg-background min-h-screen p-4 sm:p-8 font-body text-foreground">
      <div className="max-w-4xl mx-auto bg-card text-card-foreground shadow-lg shadow-primary/10 p-6 sm:p-8 rounded-lg">
        <header className="flex flex-col sm:flex-row items-center justify-between pb-8 border-b border-border">
          <div className="text-center sm:text-left">
            <h1 className="text-3xl sm:text-5xl font-bold text-foreground font-headline">{profile.name}</h1>
            <p className="text-lg sm:text-xl text-muted-foreground mt-2">{profile.title}</p>
            <div className="mt-4 flex flex-col sm:flex-row sm:items-center justify-center sm:justify-start text-sm text-muted-foreground gap-x-4 gap-y-2">
              <span className="flex items-center gap-2"><Phone size={14} /> +88015 189 25074</span>
              <span className="flex items-center gap-2"><Mail size={14} /> rabiulrami@gmail.com</span>
              <span className="flex items-center gap-2"><MapPin size={14} /> 378/1, West Shewrapara, Dhaka</span>
            </div>
          </div>
          <div className="mt-6 sm:mt-0 flex-shrink-0">
            <Image
              src={profile.profilePictureUrl}
              data-ai-hint="profile picture"
              alt={profile.name}
              width={160}
              height={160}
              className="w-32 h-32 sm:w-40 sm:h-40 rounded-full object-cover border-4 border-primary/50"
            />
          </div>
        </header>

        <main className="mt-8 grid gap-8">
          <section>
            <h2 className="text-xl sm:text-2xl font-bold font-headline text-primary border-b-2 border-border pb-2 mb-4">PROFILE</h2>
            <p className="text-foreground/90 whitespace-pre-line">
              {profile.bio}
            </p>
          </section>

          <section>
            <h2 className="text-xl sm:text-2xl font-bold font-headline text-primary border-b-2 border-border pb-2 mb-4">EDUCATION</h2>
             <div className="space-y-6">
                {profile.education.map((edu, index) => (
                  <div key={index}>
                    <h3 className="text-lg font-semibold">{edu.degree}</h3>
                    <p className="text-md text-muted-foreground">{edu.institution}</p>
                    <p className="text-sm text-muted-foreground">{edu.period}</p>
                    <p className="mt-1 text-sm text-foreground/90">{edu.focus}</p>
                  </div>
                ))}
            </div>
          </section>

          <section>
            <h2 className="text-xl sm:text-2xl font-bold font-headline text-primary border-b-2 border-border pb-2 mb-4">CERTIFICATION</h2>
            <div className="space-y-6">
              {profile.certifications.map((cert, index) => (
                <div key={index}>
                  <h3 className="text-lg font-semibold">{cert.field}</h3>
                  <p className="text-md text-muted-foreground">{cert.program}</p>
                  <p className="text-sm text-muted-foreground">{cert.period}</p>
                  <p className="mt-1 text-sm text-foreground/90">{cert.skills}</p>
                </div>
              ))}
            </div>
          </section>

          <section>
            <h2 className="text-xl sm:text-2xl font-bold font-headline text-primary border-b-2 border-border pb-2 mb-4">WORK EXPERIENCE</h2>
            <div className="space-y-6">
              {profile.experience.map((job, index) => (
                <div key={index}>
                  <h3 className="text-lg font-semibold">{job.role}</h3>
                  <p className="text-md text-muted-foreground">{job.company}</p>
                  <p className="text-sm text-muted-foreground">{job.period}</p>
                  <p className="mt-1 text-sm text-foreground/90">{job.description}</p>
                </div>
              ))}
            </div>
          </section>

          <section>
            <h2 className="text-xl sm:text-2xl font-bold font-headline text-primary border-b-2 border-border pb-2 mb-4">SKILLS</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-lg font-semibold mb-2">Software</h3>
                <ul className="list-disc list-inside text-foreground/90 space-y-1">
                  <li>Revit</li>
                  <li>AutoCAD</li>
                  <li>3ds Max</li>
                  <li>Photoshop</li>
                  <li>MS Project</li>
                  <li>MS Office (Word, Excel, PowerPoint)</li>
                  <li>Corona</li>
                  <li>V-ray</li>
                  <li>Enscape (Moderate)</li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-2">Personal</h3>
                <ul className="list-disc list-inside text-foreground/90 space-y-1">
                  <li>Leadership</li>
                  <li>Management Skills</li>
                  <li>Time Management</li>
                </ul>
              </div>
            </div>
          </section>
        </main>
      </div>
    </div>
  );
}
