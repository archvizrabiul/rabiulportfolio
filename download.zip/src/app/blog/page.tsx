import { Header } from '@/components/header';
import { Footer } from '@/components/footer';
import { getBlogPosts, getProfile } from '@/lib/data';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import Link from 'next/link';
import Image from 'next/image';
import { format } from 'date-fns';
import { ArrowRight } from 'lucide-react';

export default async function BlogPage() {
  const posts = await getBlogPosts();
  const profile = await getProfile();

  return (
    <div className="flex flex-col min-h-dvh">
      <Header isSubPage={true} profile={profile} />
      <main className="flex-1 py-12 md:py-24 lg:py-32">
        <div className="container mx-auto px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
                <div className="space-y-2">
                    <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl font-headline">Blog</h1>
                    <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                    Thoughts, tutorials, and insights on architectural visualization and AI.
                    </p>
                </div>
            </div>

            {posts.length === 0 ? (
                <p className="text-center text-muted-foreground mt-16">No blog posts found. Check back soon!</p>
            ) : (
                <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
                    {posts.map(post => (
                        <Link href={`/blog/${post.slug}`} key={post.id} className="group">
                             <Card className="overflow-hidden flex flex-col h-full bg-secondary border-2 border-transparent hover:border-primary transition-all duration-300 ease-in-out hover:shadow-lg hover:-translate-y-1">
                                <div className="overflow-hidden">
                                    <Image
                                    src={post.coverImageUrl}
                                    alt={post.title}
                                    data-ai-hint="blog cover"
                                    width={600}
                                    height={400}
                                    className="aspect-video object-cover w-full transition-transform duration-500 ease-in-out group-hover:scale-110"
                                    />
                                </div>
                                <CardHeader>
                                    <CardTitle className="font-headline text-xl group-hover:text-primary transition-colors">{post.title}</CardTitle>
                                </CardHeader>
                                <CardContent className="flex-grow">
                                   <CardDescription>{post.content.substring(0, 100)}...</CardDescription>
                                </CardContent>
                                <CardFooter className="flex justify-between items-center text-sm text-muted-foreground">
                                    <span>{post.createdAt && format(new Date(post.createdAt), 'MMMM d, yyyy')}</span>
                                    <span className="flex items-center">
                                        Read More <ArrowRight className="ml-1 h-4 w-4" />
                                    </span>
                                </CardFooter>
                            </Card>
                        </Link>
                    ))}
                </div>
            )}
        </div>
      </main>
      <Footer />
    </div>
  );
}
