import { notFound } from 'next/navigation';
import { Header } from '@/components/header';
import { Footer } from '@/components/footer';
import { getBlogPostBySlug, getProfile } from '@/lib/data';
import Image from 'next/image';
import { format } from 'date-fns';
import { marked } from 'marked';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Download, Tag, Calendar, Layers } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';

type BlogPostPageProps = {
    params: {
        slug: string;
    }
}

export default async function BlogPostPage({ params }: BlogPostPageProps) {
  const post = await getBlogPostBySlug(params.slug);
  const profile = await getProfile();

  if (!post) {
    notFound();
  }
  
  const contentHtml = await marked.parse(post.content);

  return (
    <div className="flex flex-col min-h-dvh bg-secondary/50">
      <Header isSubPage={true} profile={profile} />
      <main className="flex-1 py-12 md:py-16 lg:py-20">
        <div className="container mx-auto px-4 md:px-6">
          <header className="mb-8">
            <h1 className="text-3xl md:text-5xl font-bold tracking-tighter font-headline mb-3 text-center">{post.title}</h1>
          </header>
          
          <div className="grid lg:grid-cols-3 gap-8 lg:gap-12">
            <div className="lg:col-span-2">
                <Card className="overflow-hidden">
                    <CardContent className="p-0">
                        <Image
                            src={post.coverImageUrl}
                            alt={post.title}
                            width={1200}
                            height={675}
                            className="aspect-video object-cover w-full"
                            priority
                        />
                    </CardContent>
                </Card>
                 <article className="mt-8 bg-card p-6 sm:p-8 rounded-lg">
                     <div 
                        className="prose dark:prose-invert prose-lg max-w-none prose-headings:font-headline prose-a:text-primary hover:prose-a:text-primary/80 prose-img:rounded-lg"
                        dangerouslySetInnerHTML={{ __html: contentHtml }}
                     />
                 </article>
            </div>

            <aside className="lg:col-span-1 space-y-8">
                <Card>
                    <CardHeader>
                        <CardTitle>Post Details</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="flex items-center gap-3">
                            <Calendar className="w-5 h-5 text-primary" />
                            <div>
                                <p className="font-semibold">Published</p>
                                <p className="text-sm text-muted-foreground">{post.createdAt && format(new Date(post.createdAt), 'MMMM d, yyyy')}</p>
                            </div>
                        </div>
                        <Separator />
                         <div className="flex items-center gap-3">
                            <Layers className="w-5 h-5 text-primary" />
                            <div>
                                <p className="font-semibold">Category</p>
                                <p className="text-sm text-muted-foreground">{post.category}</p>
                            </div>
                        </div>
                        {post.tags && post.tags.length > 0 && (
                            <>
                                <Separator />
                                <div className="flex items-start gap-3">
                                    <Tag className="w-5 h-5 text-primary mt-1" />
                                    <div>
                                        <p className="font-semibold">Tags</p>
                                        <div className="flex flex-wrap gap-2 mt-2">
                                            {post.tags.map(tag => (
                                                <Badge key={tag} variant="secondary">{tag}</Badge>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                            </>
                        )}
                    </CardContent>
                </Card>

                <div className="sticky top-24">
                    <Button size="lg" className="w-full h-12 text-lg animate-pulse-glow">
                        <Download className="mr-2 h-6 w-6" /> Download
                    </Button>
                    <p className="text-xs text-center text-muted-foreground mt-2">File specific information would go here.</p>
                </div>
            </aside>
          </div>

        </div>
      </main>
      <Footer />
    </div>
  );
}
